<!DOCTYPE html>
<html lang="ru" class="fontawesome-i2svg-active fontawesome-i2svg-complete">
   <head>
      <style>.LGLeeN-keyboard-shortcuts-view{display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:flex}.LGLeeN-keyboard-shortcuts-view table,.LGLeeN-keyboard-shortcuts-view tbody,.LGLeeN-keyboard-shortcuts-view td,.LGLeeN-keyboard-shortcuts-view tr{background:inherit;border:none;margin:0;padding:0}.LGLeeN-keyboard-shortcuts-view table{display:table}.LGLeeN-keyboard-shortcuts-view tr{display:table-row}.LGLeeN-keyboard-shortcuts-view td{-moz-box-sizing:border-box;box-sizing:border-box;display:table-cell;color:#000;padding:6px;vertical-align:middle;white-space:nowrap}.LGLeeN-keyboard-shortcuts-view td:first-child{text-align:end}.LGLeeN-keyboard-shortcuts-view td kbd{background-color:#e8eaed;border-radius:2px;border:none;-moz-box-sizing:border-box;box-sizing:border-box;color:inherit;display:inline-block;font-family:Google Sans Text,Roboto,Arial,sans-serif;line-height:16px;margin:0 2px;min-height:20px;min-width:20px;padding:2px 4px;position:relative;text-align:center}</style>
      <style>.gm-control-active>img{-webkit-box-sizing:content-box;box-sizing:content-box;display:none;left:50%;pointer-events:none;position:absolute;top:50%;-webkit-transform:translate(-50%,-50%);-ms-transform:translate(-50%,-50%);-o-transform:translate(-50%,-50%);transform:translate(-50%,-50%)}.gm-control-active>img:nth-child(1){display:block}.gm-control-active:focus>img:nth-child(1),.gm-control-active:hover>img:nth-child(1),.gm-control-active:active>img:nth-child(1),.gm-control-active:disabled>img:nth-child(1){display:none}.gm-control-active:focus>img:nth-child(2),.gm-control-active:hover>img:nth-child(2){display:block}.gm-control-active:active>img:nth-child(3){display:block}.gm-control-active:disabled>img:nth-child(4){display:block}sentinel{}</style>
      <link type="text/css" rel="stylesheet" href="assets/css.css">
      <link type="text/css" rel="stylesheet" href="assets/css-1.css">
      <style>.gm-ui-hover-effect{opacity:.6}.gm-ui-hover-effect:hover{opacity:1}.gm-ui-hover-effect>span{background-color:#000}@media (forced-colors:active),(prefers-contrast:more){.gm-ui-hover-effect>span{background-color:ButtonText}}sentinel{}</style>
      <style>.gm-style .gm-style-cc a,.gm-style .gm-style-cc button,.gm-style .gm-style-cc span,.gm-style .gm-style-mtc div{font-size:10px;-webkit-box-sizing:border-box;box-sizing:border-box}.gm-style .gm-style-cc a,.gm-style .gm-style-cc button,.gm-style .gm-style-cc span{outline-offset:3px}sentinel{}</style>
      <style>@media print {  .gm-style .gmnoprint, .gmnoprint {    display:none  }}@media screen {  .gm-style .gmnoscreen, .gmnoscreen {    display:none  }}</style>
      <style>.gm-style-moc{background-color:rgba(0,0,0,.45);pointer-events:none;text-align:center;-webkit-transition:opacity ease-in-out;-o-transition:opacity ease-in-out;transition:opacity ease-in-out}.gm-style-mot{color:white;font-family:Roboto,Arial,sans-serif;font-size:22px;margin:0;position:relative;top:50%;-o-transform:translateY(-50%);transform:translateY(-50%);-webkit-transform:translateY(-50%);-ms-transform:translateY(-50%)}sentinel{}</style>
      <style>.gm-style img{max-width: none;}.gm-style {font: 400 11px Roboto, Arial, sans-serif; text-decoration: none;}</style>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
      <title>Услуги адвоката Киев ᐉ Юридическая фирма | GRACERS</title>
      <meta name="description" content="Юридическая фирма GRACERS - это адвокаты и юристы - лучшие экcперты в сложных судебных спорах ⚖️ Услуги адвоката - консультация и защита в суде">
      <!-- og:homepage -->
      <meta property="og:title" content="Услуги адвоката Киев ᐉ Юридическая фирма | GRACERS">
      <meta property="og:type" content="website">
      <meta property="og:image:type" content="image/png">
      <meta property="og:image:width" content="177">
      <meta property="og:image:height" content="47">
      <meta property="og:description" content="Юридическая фирма GRACERS - это адвокаты и юристы - лучшие экcперты в сложных судебных спорах ⚖️ Услуги адвоката - консультация и защита в суде">
      <style type="text/css">svg:not(:root).svg-inline--fa{overflow:visible}.svg-inline--fa{display:inline-block;font-size:inherit;height:1em;overflow:visible;vertical-align:-.125em}.svg-inline--fa.fa-lg{vertical-align:-.225em}.svg-inline--fa.fa-w-1{width:.0625em}.svg-inline--fa.fa-w-2{width:.125em}.svg-inline--fa.fa-w-3{width:.1875em}.svg-inline--fa.fa-w-4{width:.25em}.svg-inline--fa.fa-w-5{width:.3125em}.svg-inline--fa.fa-w-6{width:.375em}.svg-inline--fa.fa-w-7{width:.4375em}.svg-inline--fa.fa-w-8{width:.5em}.svg-inline--fa.fa-w-9{width:.5625em}.svg-inline--fa.fa-w-10{width:.625em}.svg-inline--fa.fa-w-11{width:.6875em}.svg-inline--fa.fa-w-12{width:.75em}.svg-inline--fa.fa-w-13{width:.8125em}.svg-inline--fa.fa-w-14{width:.875em}.svg-inline--fa.fa-w-15{width:.9375em}.svg-inline--fa.fa-w-16{width:1em}.svg-inline--fa.fa-w-17{width:1.0625em}.svg-inline--fa.fa-w-18{width:1.125em}.svg-inline--fa.fa-w-19{width:1.1875em}.svg-inline--fa.fa-w-20{width:1.25em}.svg-inline--fa.fa-pull-left{margin-right:.3em;width:auto}.svg-inline--fa.fa-pull-right{margin-left:.3em;width:auto}.svg-inline--fa.fa-border{height:1.5em}.svg-inline--fa.fa-li{width:2em}.svg-inline--fa.fa-fw{width:1.25em}.fa-layers svg.svg-inline--fa{bottom:0;left:0;margin:auto;position:absolute;right:0;top:0}.fa-layers{display:inline-block;height:1em;position:relative;text-align:center;vertical-align:-.125em;width:1em}.fa-layers svg.svg-inline--fa{-webkit-transform-origin:center center;transform-origin:center center}.fa-layers-counter,.fa-layers-text{display:inline-block;position:absolute;text-align:center}.fa-layers-text{left:50%;top:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);-webkit-transform-origin:center center;transform-origin:center center}.fa-layers-counter{background-color:#ff253a;border-radius:1em;-webkit-box-sizing:border-box;box-sizing:border-box;color:#fff;height:1.5em;line-height:1;max-width:5em;min-width:1.5em;overflow:hidden;padding:.25em;right:0;text-overflow:ellipsis;top:0;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:top right;transform-origin:top right}.fa-layers-bottom-right{bottom:0;right:0;top:auto;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:bottom right;transform-origin:bottom right}.fa-layers-bottom-left{bottom:0;left:0;right:auto;top:auto;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:bottom left;transform-origin:bottom left}.fa-layers-top-right{right:0;top:0;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:top right;transform-origin:top right}.fa-layers-top-left{left:0;right:auto;top:0;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:top left;transform-origin:top left}.fa-lg{font-size:1.3333333333em;line-height:.75em;vertical-align:-.0667em}.fa-xs{font-size:.75em}.fa-sm{font-size:.875em}.fa-1x{font-size:1em}.fa-2x{font-size:2em}.fa-3x{font-size:3em}.fa-4x{font-size:4em}.fa-5x{font-size:5em}.fa-6x{font-size:6em}.fa-7x{font-size:7em}.fa-8x{font-size:8em}.fa-9x{font-size:9em}.fa-10x{font-size:10em}.fa-fw{text-align:center;width:1.25em}.fa-ul{list-style-type:none;margin-left:2.5em;padding-left:0}.fa-ul>li{position:relative}.fa-li{left:-2em;position:absolute;text-align:center;width:2em;line-height:inherit}.fa-border{border:solid .08em #eee;border-radius:.1em;padding:.2em .25em .15em}.fa-pull-left{float:left}.fa-pull-right{float:right}.fa.fa-pull-left,.fab.fa-pull-left,.fal.fa-pull-left,.far.fa-pull-left,.fas.fa-pull-left{margin-right:.3em}.fa.fa-pull-right,.fab.fa-pull-right,.fal.fa-pull-right,.far.fa-pull-right,.fas.fa-pull-right{margin-left:.3em}.fa-spin{-webkit-animation:fa-spin 2s infinite linear;animation:fa-spin 2s infinite linear}.fa-pulse{-webkit-animation:fa-spin 1s infinite steps(8);animation:fa-spin 1s infinite steps(8)}@-webkit-keyframes fa-spin{0%{-webkit-transform:rotate(0);transform:rotate(0)}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}@keyframes fa-spin{0%{-webkit-transform:rotate(0);transform:rotate(0)}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}.fa-rotate-90{-webkit-transform:rotate(90deg);transform:rotate(90deg)}.fa-rotate-180{-webkit-transform:rotate(180deg);transform:rotate(180deg)}.fa-rotate-270{-webkit-transform:rotate(270deg);transform:rotate(270deg)}.fa-flip-horizontal{-webkit-transform:scale(-1,1);transform:scale(-1,1)}.fa-flip-vertical{-webkit-transform:scale(1,-1);transform:scale(1,-1)}.fa-flip-both,.fa-flip-horizontal.fa-flip-vertical{-webkit-transform:scale(-1,-1);transform:scale(-1,-1)}:root .fa-flip-both,:root .fa-flip-horizontal,:root .fa-flip-vertical,:root .fa-rotate-180,:root .fa-rotate-270,:root .fa-rotate-90{-webkit-filter:none;filter:none}.fa-stack{display:inline-block;height:2em;position:relative;width:2.5em}.fa-stack-1x,.fa-stack-2x{bottom:0;left:0;margin:auto;position:absolute;right:0;top:0}.svg-inline--fa.fa-stack-1x{height:1em;width:1.25em}.svg-inline--fa.fa-stack-2x{height:2em;width:2.5em}.fa-inverse{color:#fff}.sr-only{border:0;clip:rect(0,0,0,0);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px}.sr-only-focusable:active,.sr-only-focusable:focus{clip:auto;height:auto;margin:0;overflow:visible;position:static;width:auto}</style>
      <link href="assets/favicon.png" rel="icon">
      <link href="assets/favicon.png" rel="shortcut icon">
      <link href="assets/icon-font.min.css" rel="stylesheet">
      <link href="assets/font-awesome.min.css" rel="stylesheet">
      <link href="assets/css.minify.php.css" rel="stylesheet">
      <script type="text/javascript" src="assets/jquery.min.js"></script>
	  <script src="assets/head.load.min.js"></script>
      <link type="text/css" rel="stylesheet" href="assets/enscroll.css">
      <script type="text/javascript" src="assets/validator.js"></script>
      <link type="text/css" rel="stylesheet" href="assets/jquery.fancybox.css">
      <link type="text/css" rel="stylesheet" href="assets/owl.carousel.css">
      <script type="text/javascript" src="assets/owl.carousel.min.js"></script><script type="text/javascript" src="assets/jquery-ui.min.js"></script><script type="text/javascript" src="assets/bootstrap.min.js"></script><script type="text/javascript" src="assets/all.min.js"></script><script type="text/javascript" src="assets/jquery.autocomplete.js"></script><script type="text/javascript" src="assets/enscroll-0.6.2.min.js"></script><script type="text/javascript" src="assets/jquery.data-height.js"></script><script type="text/javascript" src="assets/jquery.inputmask.js"></script><script type="text/javascript" src="assets/jquery.visible.min.js"></script><script type="text/javascript" src="assets/jquery.data-lime.js"></script><script type="text/javascript" src="assets/jquery.mCustomScrollbar.concat.min.js"></script><script type="text/javascript" src="assets/main.js"></script><script type="text/javascript" src="assets/scroll-to-top.js"></script><script type="text/javascript" src="assets/jquery.fancybox.min.js"></script><script type="text/javascript" src="assets/lazysizes.min.js"></script><script type="text/javascript" src="assets/iframe-video.js"></script><script type="text/javascript" src="assets/api.js"></script>
      <script type="text/javascript" charset="UTF-8" src="assets/common.js"></script><script type="text/javascript" charset="UTF-8" src="assets/util.js"></script><script type="text/javascript" charset="UTF-8" src="assets/map.js"></script><script type="text/javascript" charset="UTF-8" src="assets/marker.js"></script>
      <script type="text/javascript" charset="UTF-8" src="assets/onion.js"></script><script type="text/javascript" charset="UTF-8" src="assets/controls.js"></script>
<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '6917040938362657');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=6917040938362657&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->
   </head>
   <body class="public pageHome">
      <div class="hidden" id="LANG">ru</div>
      <header class="header relative">
         <div class="header__top header__top--home">
            <div class="header__top-line hidden-lg hidden-md" data-height="header" data-height-sm="" data-height-xs="" style="height: 0px;">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="text-right relative">
                           <div class="header__navbar-header navbar-header">
                              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse2">
                                 <svg class="svg-inline--fa fa-bars fa-w-14" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="bars" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg="">
                                    <path fill="currentColor" d="M16 132h416c8.837 0 16-7.163 16-16V76c0-8.837-7.163-16-16-16H16C7.163 60 0 67.163 0 76v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16z"></path>
                                 </svg>
                                 <!-- <i class="fas fa-bars"></i> -->
                              </button>
                              <span class="navbar-brand"><img src="assets/logo-ru.png" alt="Услуги адвоката"></span>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div>
               <div class="container">
                  <div class="row">
                     <div class="col-lg-4 col-md-3 hidden-sm hidden-xs">
                        <div class="header__logo">
                           <span class="navbar-brand"><img src="assets/logo-ru.png" alt="Услуги адвоката"></span>
                        </div>
                     </div>
                     <div class="col-lg-8 col-md-9 col-sm-12 col-xs-12">
                        <div class="header__table">
                           <div class="header__td header__td--right">
                              <div class="navbar navbar-default navbar__lime" role="navigation">
                                 <div class="collapse navbar-collapse hidden-sm hidden-xs">
                                    <ul class="nav navbar-nav main-menu">
                                       <li class="dropdown">
                                          <a class="dropdown-toggle dropdown-toggle-level1 hidden-sm hidden-xs" href="#"><span>Практики</span></a>
                                          <a class="dropdown-toggle dropdown-toggle-level1 hidden-lg hidden-md" href="#"><span>Практики</span></a>
                                          <ul class="dropdown-menu multi-level">
                                             <div class="dropdown-menu__wrapper row">
                                                <li class="">
                                                   <a class="dropdown-toggle dropdown-toggle-level2" href="#"><span>Уголовное право и процесс</span></a>
                                                </li>
                                                <li class="">
                                                   <a class="dropdown-toggle dropdown-toggle-level2" href="#"><span>Судебная практика</span></a>
                                                </li>
                                                <li class="">
                                                   <a class="dropdown-toggle dropdown-toggle-level2" href="#"><span>Исполнительное производство</span></a>
                                                </li>
                                                <li class="">
                                                   <a class="dropdown-toggle dropdown-toggle-level2" href="#"><span>GR - взаимодействие с органами государственной власти</span></a>
                                                </li>
                                                <li class="">
                                                   <a class="dropdown-toggle dropdown-toggle-level2" href="#"><span>Семейное право</span></a>
                                                </li>
                                                <li class="">
                                                   <a class="dropdown-toggle dropdown-toggle-level2" href="#"><span>Налоговое право</span></a>
                                                </li>
                                                <li class="">
                                                   <a class="dropdown-toggle dropdown-toggle-level2" href="#"><span>Защита бизнеса</span></a>
                                                </li>
                                                <li class="">
                                                   <a class="dropdown-toggle dropdown-toggle-level2" href="#"><span>Поддержка IT-компаний</span></a>
                                                </li>
                                             </div>
                                          </ul>
                                       </li>
                                       <li class="">
                                          <a class="dropdown-toggle dropdown-toggle-level1 hidden-sm hidden-xs" href="#"><span>О нас</span></a>
                                          <a class="dropdown-toggle dropdown-toggle-level1 hidden-lg hidden-md" href="#"><span>О нас</span></a>
                                       </li>
                                       <li class="">
                                          <a class="dropdown-toggle dropdown-toggle-level1 hidden-sm hidden-xs" href="#"><span>Команда</span></a>
                                          <a class="dropdown-toggle dropdown-toggle-level1 hidden-lg hidden-md" href="#"><span>Команда</span></a>
                                       </li>
                                       <li class="">
                                          <a class="dropdown-toggle dropdown-toggle-level1 hidden-sm hidden-xs" href="#"><span>Пресс-центр</span></a>
                                          <a class="dropdown-toggle dropdown-toggle-level1 hidden-lg hidden-md" href="#"><span>Пресс-центр</span></a>
                                       </li>
                                       <li class="">
                                          <a class="dropdown-toggle dropdown-toggle-level1 hidden-sm hidden-xs" href="#"><span>Контакты</span></a>
                                          <a class="dropdown-toggle dropdown-toggle-level1 hidden-lg hidden-md" href="#"><span>Контакты</span></a>
                                       </li>
                                    </ul>
                                 </div>
                              </div>
                              <div class="header__langs-phones-wrapper hidden-sm hidden-xs">
                                 <div class="header__langs relative">
                                    <span class="dropdown-toggle" type="button" id="headerlang" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Рус&nbsp;<span class="lnr lnr-chevron-down"></span></span>
                                    <div class="dropdown-menu pull-right header-langs-dropdown" aria-labelledby="headerlang">
                                       <div><a href="#">Укр</a></div>
                                       <div><a href="#">Eng</a></div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="hidden-lg hidden-md navbar navbar-default navbar__lime">
                  <div class="collapse navbar-collapse navbar-collapse2">
                     <div class="header__langs-phones-wrapper">
                        <div class="header__langs relative">
                           <span class="dropdown-toggle" type="button" id="headerlang" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Рус&nbsp;<span class="lnr lnr-chevron-down"></span></span>
                           <div class="dropdown-menu header-langs-dropdown" aria-labelledby="headerlang">
                              <div><a href="#">Укр</a></div>
                              <div><a href="#">Eng</a></div>
                           </div>
                        </div>
                     </div>
                     <ul class="nav navbar-nav main-menu">
                        <li class="dropdown">
                           <a class="dropdown-toggle dropdown-toggle-level1 hidden-lg hidden-md" data-toggle="dropdown" href="#">
                           <span>Практики</span>
                           <i class="lnr lnr-chevron-down"></i><i class="lnr lnr-chevron-up"></i>
                           </a>
                           <ul class="dropdown-menu multi-level">
                              <div class="dropdown-menu__wrapper">
                                 <li class="">
                                    <a class="dropdown-toggle dropdown-toggle-level2" href="#"><span>Уголовное право и процесс</span></a>
                                 </li>
                                 <li class="">
                                    <a class="dropdown-toggle dropdown-toggle-level2" href="#"><span>Судебная практика</span></a>
                                 </li>
                                 <li class="">
                                    <a class="dropdown-toggle dropdown-toggle-level2" href="#"><span>Исполнительное производство</span></a>
                                 </li>
                                 <li class="">
                                    <a class="dropdown-toggle dropdown-toggle-level2" href="#"><span>GR - взаимодействие с органами государственной власти</span></a>
                                 </li>
                                 <li class="">
                                    <a class="dropdown-toggle dropdown-toggle-level2" href="#"><span>Семейное право</span></a>
                                 </li>
                                 <li class="">
                                    <a class="dropdown-toggle dropdown-toggle-level2" href="#"><span>Налоговое право</span></a>
                                 </li>
                                 <li class="">
                                    <a class="dropdown-toggle dropdown-toggle-level2" href="#"><span>Защита бизнеса</span></a>
                                 </li>
                                 <li class="">
                                    <a class="dropdown-toggle dropdown-toggle-level2" href="#"><span>Поддержка IT-компаний</span></a>
                                 </li>
                              </div>
                           </ul>
                        </li>
                        <li class="">
                           <a class="dropdown-toggle dropdown-toggle-level1 hidden-lg hidden-md" href="#">
                           <span>О нас</span>
                           </a>
                        </li>
                        <li class="">
                           <a class="dropdown-toggle dropdown-toggle-level1 hidden-lg hidden-md" href="#">
                           <span>Команда</span>
                           </a>
                        </li>
                        <li class="">
                           <a class="dropdown-toggle dropdown-toggle-level1 hidden-lg hidden-md" href="#">
                           <span>Пресс-центр</span>
                           </a>
                        </li>
                        <li class="">
                           <a class="dropdown-toggle dropdown-toggle-level1 hidden-lg hidden-md" href="#">
                           <span>Контакты</span>
                           </a>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
         <div class="header__bottom">
            <div class="owl-allwork__wrapper">
               <div class="owl-allwork owl-nav-center owl-dots-center" id="block62">
                  <div class="owl-allwork__item relative">
                     <img data-src="assets/banner.jpg" class="lazyload owl-allwork__item__image" alt="SAFE LEGAL SPEED"/>
                  </div>
                  <div class="owl-allwork__item relative">
                     <img data-src="assets/awards.jpg" class="lazyload owl-allwork__item__image" alt=""/>
                  </div>
               </div>
            </div>
            <script>
               head.ready(function() {
                   $("#block62").owlCarousel({
                       items: 1,
                       loop: true,
                                           dots: true,
                                       nav: false,
                       autoHeight: false,
                       //navText: ["<span class='fa fa-angle-left'></span>", "<span class='fa fa-angle-right'></span>"],
                       autoplay: true,
                       autoplayTimeout: 10000,
                       autoplayHoverPause: true,
                   });
               });
            </script>
            <script>
               head.js("/js/owl-carousel/owl.carousel.min.js");
               head.load("/js/owl-carousel/css/owl.carousel.css");
            </script>
         </div>
      </header>
      <div class="container relative">
         <div>
         </div>
      </div>
      <div class="maincontent">
         <div>
            <div id="blockcenter" class="bordAdm">
               <div class="last-service-anons__bg">
                  <div class="container">
                     <div class="row rowpad0">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                           <div class="h2__title">
                              <div class="h2__icon">
                                 <span></span>
                                 <span></span>
                                 <span></span>
                              </div>
                              Практики
                           </div>
                           <div class="blockRawHtml--pl about-block__text">
                              <p>Основная практика GRACERS - это White Collar Crimes, представительство интересов и защита в уголовных производствах по хозяйственной и служебной деятельности, сложная многогранность которых выходит за рамки уголовного права и процесса.</p>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="container" id="serviceListHome">
                     <div class="row rowpad0 content-service__anons-items">
                        <div class="col-lg-3 col-md-3 col-sm-4 col-xs-6 content-service__anons-item--home__wrapper">
                           <div class="content-service__anons-item content-service__anons-item--home relative">
                              <div class="content-service__anons-item__content">
                                 <a href="#" class="content-service__anons-item__overlay last-service__anons-item__overlay">
                                    <div class="content-service__anons-item__overlay-content">
                                       <div class="content-service__anons-item__icon">
                                          <img class=" ls-is-cached lazyloaded" data-src="assets//data/service_item/23/23_b.png" alt="icon Уголовное право и процесс" src="assets/23_b.png">
                                       </div>
                                       <div class="content-service__anons-item__name" data-height="content-service-name" style="height: 77px;">Уголовное право и процесс</div>
                                    </div>
                                 </a>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-4 col-xs-6 content-service__anons-item--home__wrapper content-service__anons-item--home__wrapper--2">
                           <div class="content-service__anons-item content-service__anons-item--home relative">
                              <div class="content-service__anons-item__content">
                                 <a href="#" class="content-service__anons-item__overlay last-service__anons-item__overlay">
                                    <div class="content-service__anons-item__overlay-content">
                                       <div class="content-service__anons-item__icon">
                                          <img class=" ls-is-cached lazyloaded" data-src="assets//data/service_item/24/24_b.png" alt="icon Судебная практика" src="assets/24_b.png">
                                       </div>
                                       <div class="content-service__anons-item__name" data-height="content-service-name" style="height: 77px;">Судебная практика</div>
                                    </div>
                                 </a>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-4 col-xs-6 content-service__anons-item--home__wrapper content-service__anons-item--home__wrapper--3">
                           <div class="content-service__anons-item content-service__anons-item--home relative">
                              <div class="content-service__anons-item__content">
                                 <a href="#" class="content-service__anons-item__overlay last-service__anons-item__overlay">
                                    <div class="content-service__anons-item__overlay-content">
                                       <div class="content-service__anons-item__icon">
                                          <img class=" ls-is-cached lazyloaded" data-src="assets//data/service_item/26/26_b.png" alt="icon Исполнительное производство" src="assets/26_b.png">
                                       </div>
                                       <div class="content-service__anons-item__name" data-height="content-service-name" style="height: 77px;">Исполнительное производство</div>
                                    </div>
                                 </a>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-4 col-xs-6 content-service__anons-item--home__wrapper content-service__anons-item--home__wrapper--2 content-service__anons-item--home__wrapper--4">
                           <div class="content-service__anons-item content-service__anons-item--home relative">
                              <div class="content-service__anons-item__content">
                                 <a href="#" class="content-service__anons-item__overlay last-service__anons-item__overlay">
                                    <div class="content-service__anons-item__overlay-content">
                                       <div class="content-service__anons-item__icon">
                                          <img class=" ls-is-cached lazyloaded" data-src="assets//data/service_item/62/62_b.png" alt="icon GR - взаимодействие с органами государственной власти" src="assets/62_b.png">
                                       </div>
                                       <div class="content-service__anons-item__name" data-height="content-service-name" style="height: 77px;">GR - взаимодействие с органами государственной власти</div>
                                    </div>
                                 </a>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-4 col-xs-6 content-service__anons-item--home__wrapper">
                           <div class="content-service__anons-item content-service__anons-item--home relative">
                              <div class="content-service__anons-item__content">
                                 <a href="#" class="content-service__anons-item__overlay last-service__anons-item__overlay">
                                    <div class="content-service__anons-item__overlay-content">
                                       <div class="content-service__anons-item__icon">
                                          <img class=" lazyloaded" data-src="assets//data/service_item/60/60_b.png" alt="icon Семейное право" src="assets/60_b.png">
                                       </div>
                                       <div class="content-service__anons-item__name" data-height="content-service-name" style="height: 77px;">Семейное право</div>
                                    </div>
                                 </a>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-4 col-xs-6 content-service__anons-item--home__wrapper content-service__anons-item--home__wrapper--2 content-service__anons-item--home__wrapper--3">
                           <div class="content-service__anons-item content-service__anons-item--home relative">
                              <div class="content-service__anons-item__content">
                                 <a href="#" class="content-service__anons-item__overlay last-service__anons-item__overlay">
                                    <div class="content-service__anons-item__overlay-content">
                                       <div class="content-service__anons-item__icon">
                                          <img class=" lazyloaded" data-src="assets//data/service_item/25/25_b.png" alt="icon Налоговое право" src="assets/25_b.png">
                                       </div>
                                       <div class="content-service__anons-item__name" data-height="content-service-name" style="height: 77px;">Налоговое право</div>
                                    </div>
                                 </a>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-4 col-xs-6 content-service__anons-item--home__wrapper">
                           <div class="content-service__anons-item content-service__anons-item--home relative">
                              <div class="content-service__anons-item__content">
                                 <a href="#" class="content-service__anons-item__overlay last-service__anons-item__overlay">
                                    <div class="content-service__anons-item__overlay-content">
                                       <div class="content-service__anons-item__icon">
                                          <img class=" lazyloaded" data-src="assets//data/service_item/27/27_b.png" alt="icon Защита бизнеса" src="assets/27_b.png">
                                       </div>
                                       <div class="content-service__anons-item__name" data-height="content-service-name" style="height: 77px;">Защита бизнеса</div>
                                    </div>
                                 </a>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-4 col-xs-6 content-service__anons-item--home__wrapper content-service__anons-item--home__wrapper--2 content-service__anons-item--home__wrapper--4">
                           <div class="content-service__anons-item content-service__anons-item--home relative">
                              <div class="content-service__anons-item__content">
                                 <a href="#" class="content-service__anons-item__overlay last-service__anons-item__overlay">
                                    <div class="content-service__anons-item__overlay-content">
                                       <div class="content-service__anons-item__icon">
                                          <img class=" lazyloaded" data-src="assets//data/service_item/61/61_b.png" alt="icon Поддержка IT-компаний" src="assets/61_b.png">
                                       </div>
                                       <div class="content-service__anons-item__name" data-height="content-service-name" style="height: 77px;">Поддержка IT-компаний</div>
                                    </div>
                                 </a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="form__wrapper">
               <div class="form__wrapper__bg" style="left: 993.188px;"></div>
               <div class="container form__wrapper__container">
                  <div class="row">
                     <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="h2__title">
                           <div class="h2__icon">
                              <span></span>
                              <span></span>
                              <span></span>
                           </div>
                           Наша команда
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div id="block_68" class="form2__inner">
                           <div class="form2">
                              <div class="form2__container">
                                 <div class="row">
                                    <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                                       <div id="form1" class="form__content" data-height="foorm-height" data-height-sm="" style="height: 236px;">
                                          <div class="form__text form__text--top">
                                             <p>GRACERS - монолитная команда высококвалифицированных экспертов в области права, которая нацелена на достижение благоприятного и эффективного результата в интересах клиента.</p>
                                          </div>
                                          <div class="form__text form__text--bottom">GRACERS объединяет экcпертов в сложных судебных спорах. Наши адвокаты специализируются в защите от уголовного преследования. Каждый наш клиент получает высокопрофессиональную правовую помощь. Мы имеем значительный опыт работы в качестве советников, арбитров, экспертов во многих отраслях права.</div>
                                          <div class="text-center">
                                             <button class="hidden-lg hidden-md hidden-sm cms__btn cms__btn--form" onclick="$('#teamForm').removeClass('hidden-xs');$(this).addClass('dnone');">НАПИСАТЬ НАМ</button>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                       <div id="teamForm" class="hidden-xs" data-height="form-height" data-height-sm="" style="height: 460px;">
                                          <div class="form2__title form2__title--white">Задать вопрос</div>
                                          <div class="form2__message">Задайте вопрос нашим юристам</div>
                                          <div class="feedback-googlemap__form" id="feedback_form_form">
                                             <div class="alert alert-info hidden" id="feedback_ok">Ваше сообщение отправлено!</div>
                                             <form id="feedback_form68" method="post" action="spasibo.php" role="form" class="cms-form" data-toggle="validator" novalidate="true">
                                                <input type="hidden" name="form" value="block-submit">
                                                <input type="hidden" name="cat_id" value="23">
                                                <input type="hidden" name="url" value="/ru/glavnaya/">
                                                <input type="hidden" name="block_id" value="68">
                                                <input type="hidden" name="block_type" value="Form">
                                                <input type="hidden" name="action" value="addfback">
                                                <div id="block_68_errors">
                                                   <div>
                                                   </div>
                                                </div>
                                                <div>
                                                   <div class="row">
                                                      <div class="col-sm-12 form-group">
                                                         <input type="text" name="feedback[name]" value="" class="form-control" required="" placeholder="Имя*">
                                                      </div>
                                                   </div>
                                                   <div class="row">
                                                      <div class="col-sm-12 form-group">
                                                         <input type="text" name="feedback[phone]" value="" class="form-control mobile" placeholder="Телефон" inputmode="text">
                                                      </div>
                                                   </div>
                                                   <div class="row">
                                                      <div class="col-sm-12 form-group">
                                                         <input type="email" name="feedback[email]" value="" class="form-control" required="" placeholder="E-mail*">
                                                      </div>
                                                   </div>
                                                   <div class="row">
                                                      <div class="col-sm-12 form-group">
                                                         <textarea name="feedback[comment]" class="form-control form2__textarea" required="" placeholder="Ваше сообщение*"></textarea>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="row feedback-googlemap-form__btn">
                                                   <div class="col-sm-12 text-center">
                                                      <button type="submit" class="cms__btn cms__btn--form disabled">Задать вопрос</button>
                                                   </div>
                                                </div>
                                             </form>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="container">
               <script>
                  var correctCaptcha_1 = function(response) {
                      $("#response1").val(response);
                  };
                  head.ready(function() {
                      window.addEventListener('DOMContentLoaded', function() {
                          $('form#feedback_form68').validator().on('submit', function (e) {
                              if (e.isDefaultPrevented()) {
                                  //console.log('validation error');
                              } else {
                                  e.preventDefault();
                  
                                  // var response = grecaptcha.getResponse();
                                  var response = $("#response1").val();
                                  if (response.length == 0) {
                                      // reCaptcha not verified
                                      $('form#feedback_form68 .g-recaptcha').addClass('error');
                                  } else {
                                      //reCaptch verified
                                      $('form#feedback_form68 .g-recaptcha').removeClass('error');
                                      $.ajax({
                                          type: "POST",
                                          cache: false,
                                          url: "spasibo.php",
                                          data: $(this).serialize(),
                                          success: function (data) {
                                              $('#block_68').append(data);
                                          }
                                      });
                                  }
                              }
                          });
                      });
                  });
               </script>
            </div>
            <div class="last-article__bg--home">
               <div class="container">
                  <div class="row rowpad16">
                     <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 content-author__anons-item__col">
                        <div class="content-author__anons-item">
                           <div class="content-author__anons-item__image content-author__anons-item__image--home relative">
                              <div class="content-author__anons-item__image__overlay"></div>
                              <a class="content-author__anons-item__image__link" href="##28" title="Сергей Лысенко">
                              <img class=" ls-is-cached lazyloaded" data-src="assets//data_resized/7/a/c/4/4/7ac4495153fa369a242b0df2eb598d0dbda6b90b.jpeg" alt="Сергей Лысенко" src="assets/7ac4495153fa369a242b0df2eb598d0dbda6b90b.jpeg">
                              </a>
                           </div>
                           <div class="content-author__anons-item__info">
                              <div class="content-author__anons-item__info__left" data-height="list-author-info" data-height-sm="" data-height-xs="" style="height: 59px;">
                                 <div class="content-author__anons-item__info__name"><a href="##28">Сергей Лысенко</a></div>
                                 <div class="content-author__anons-item__info__position"><a href="##28">управляющий партнер</a></div>
                              </div>
                              <div class="content-author__anons-item__info__right" data-height="list-author-info" data-height-sm="" data-height-xs="" style="height: 59px;">
                                 <a class="content-author__anons-item__info__more" href="##28">
                                    <svg class="svg-inline--fa fa-bars fa-w-14" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="bars" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg="">
                                       <path fill="currentColor" d="M16 132h416c8.837 0 16-7.163 16-16V76c0-8.837-7.163-16-16-16H16C7.163 60 0 67.163 0 76v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16z"></path>
                                    </svg>
                                    <!-- <i class="fas fa-bars"></i> -->
                                 </a>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 content-author__anons-item__col">
                        <div class="content-author__anons-item">
                           <div class="content-author__anons-item__image content-author__anons-item__image--home relative">
                              <div class="content-author__anons-item__image__overlay"></div>
                              <a class="content-author__anons-item__image__link" href="##64" title="Людмила Куса">
                              <img class=" ls-is-cached lazyloaded" data-src="assets//data_resized/5/2/9/b/c/529bcf49595cec670faf8ac56082165d4e1c1eb8.jpeg" alt="Людмила Куса" src="assets/529bcf49595cec670faf8ac56082165d4e1c1eb8.jpeg">
                              </a>
                           </div>
                           <div class="content-author__anons-item__info">
                              <div class="content-author__anons-item__info__left" data-height="list-author-info" data-height-sm="" data-height-xs="" style="height: 59px;">
                                 <div class="content-author__anons-item__info__name"><a href="##64">Людмила Куса</a></div>
                                 <div class="content-author__anons-item__info__position"><a href="##64">партнер, руководитель практики решения споров</a></div>
                              </div>
                              <div class="content-author__anons-item__info__right" data-height="list-author-info" data-height-sm="" data-height-xs="" style="height: 59px;">
                                 <a class="content-author__anons-item__info__more" href="##64">
                                    <svg class="svg-inline--fa fa-bars fa-w-14" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="bars" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg="">
                                       <path fill="currentColor" d="M16 132h416c8.837 0 16-7.163 16-16V76c0-8.837-7.163-16-16-16H16C7.163 60 0 67.163 0 76v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16z"></path>
                                    </svg>
                                    <!-- <i class="fas fa-bars"></i> -->
                                 </a>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 content-author__anons-item__col">
                        <div class="content-author__anons-item">
                           <div class="content-author__anons-item__image content-author__anons-item__image--home relative">
                              <div class="content-author__anons-item__image__overlay"></div>
                              <a class="content-author__anons-item__image__link" href="##29" title="Денис Соловей">
                              <img class=" ls-is-cached lazyloaded" data-src="assets//data_resized/0/1/e/e/e/01eeeadc4cf13cb7031106a0121bef7df2933d43.jpeg" alt="Денис Соловей" src="assets/01eeeadc4cf13cb7031106a0121bef7df2933d43.jpeg">
                              </a>
                           </div>
                           <div class="content-author__anons-item__info">
                              <div class="content-author__anons-item__info__left" data-height="list-author-info" data-height-sm="" data-height-xs="" style="height: 59px;">
                                 <div class="content-author__anons-item__info__name"><a href="##29">Денис Соловей</a></div>
                                 <div class="content-author__anons-item__info__position"><a href="##29">партнер</a></div>
                              </div>
                              <div class="content-author__anons-item__info__right" data-height="list-author-info" data-height-sm="" data-height-xs="" style="height: 59px;">
                                 <a class="content-author__anons-item__info__more" href="##29">
                                    <svg class="svg-inline--fa fa-bars fa-w-14" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="bars" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg="">
                                       <path fill="currentColor" d="M16 132h416c8.837 0 16-7.163 16-16V76c0-8.837-7.163-16-16-16H16C7.163 60 0 67.163 0 76v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16z"></path>
                                    </svg>
                                    <!-- <i class="fas fa-bars"></i> -->
                                 </a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
                        <div class="last-article__all-items">
                           <a href="#">
                              Вся команда&nbsp;
                              <svg class="svg-inline--fa fa-chevron-right fa-w-10" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="chevron-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" data-fa-i2svg="">
                                 <path fill="currentColor" d="M285.476 272.971L91.132 467.314c-9.373 9.373-24.569 9.373-33.941 0l-22.667-22.667c-9.357-9.357-9.375-24.522-.04-33.901L188.505 256 34.484 101.255c-9.335-9.379-9.317-24.544.04-33.901l22.667-22.667c9.373-9.373 24.569-9.373 33.941 0L285.475 239.03c9.373 9.372 9.373 24.568.001 33.941z"></path>
                              </svg>
                              <!-- <i class="fas fa-chevron-right"></i> -->
                           </a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="container">
               <div class="clear"></div>
            </div>
            <div class="about-advantage__bg about-advantage__bg--home">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="h2__title">
                           <div class="h2__icon">
                              <span></span>
                              <span></span>
                              <span></span>
                           </div>
                           Наши преимущества
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-lg-3 col-md-3 col-sm-4 col-xs-6 about-advantage__item__col">
                        <div class="about-advantage__item__wrapper">
                           <div class="about-advantage__item about-advantage__item--home">
                              <div class="about-advantage__item__inner">
                                 <div class="about-advantage__item__content">
                                    <div class="about-advantage__item__icon"><img class=" lazyloaded" data-src="assets//data/about_advantage_item/46/46_a.png" alt="Большой опыт работы" src="assets/46_a.png"></div>
                                    <div class="about-advantage__item__name">Большой опыт работы</div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-3 col-md-3 col-sm-4 col-xs-6 about-advantage__item__col">
                        <div class="about-advantage__item__wrapper">
                           <div class="about-advantage__item about-advantage__item--home">
                              <div class="about-advantage__item__inner">
                                 <div class="about-advantage__item__content">
                                    <div class="about-advantage__item__icon"><img class=" lazyloaded" data-src="assets//data/about_advantage_item/45/45_a.png" alt="Команда профессионалов" src="assets/45_a.png"></div>
                                    <div class="about-advantage__item__name">Команда профессионалов</div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="clearfix visible-xs-block"></div>
                     <div class="col-lg-3 col-md-3 col-sm-4 col-xs-6 about-advantage__item__col">
                        <div class="about-advantage__item__wrapper">
                           <div class="about-advantage__item about-advantage__item--home">
                              <div class="about-advantage__item__inner">
                                 <div class="about-advantage__item__content">
                                    <div class="about-advantage__item__icon"><img class=" lazyloaded" data-src="assets//data/about_advantage_item/44/44_a.png" alt="Комплексное сопровождение" src="assets/44_a.png"></div>
                                    <div class="about-advantage__item__name">Комплексное сопровождение</div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="clearfix visible-sm-block"></div>
                     <div class="col-lg-3 col-md-3 col-sm-4 col-xs-6 about-advantage__item__col">
                        <div class="about-advantage__item__wrapper">
                           <div class="about-advantage__item about-advantage__item--home">
                              <div class="about-advantage__item__inner">
                                 <div class="about-advantage__item__content">
                                    <div class="about-advantage__item__icon"><img class=" lazyloaded" data-src="assets//data/about_advantage_item/43/43_a.png" alt="Круглосуточная поддержка" src="assets/43_a.png"></div>
                                    <div class="about-advantage__item__name">Круглосуточная поддержка</div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="clearfix visible-lg-block visible-md-block"></div>
                     <div class="clearfix visible-xs-block"></div>
                  </div>
               </div>
            </div>
            <div class="container">
            </div>
            <div class="last-article__bg--home">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 relative">
                        <div class="h2__title">
                           <div class="h2__icon">
                              <span></span>
                              <span></span>
                              <span></span>
                           </div>
                           Последние новости
                        </div>
                        <div class="hidden-xs last-article__all-items">
                           <a href="#">
                              ВСІ СТАТТІ&nbsp;
                              <svg class="svg-inline--fa fa-chevron-right fa-w-10" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="chevron-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" data-fa-i2svg="">
                                 <path fill="currentColor" d="M285.476 272.971L91.132 467.314c-9.373 9.373-24.569 9.373-33.941 0l-22.667-22.667c-9.357-9.357-9.375-24.522-.04-33.901L188.505 256 34.484 101.255c-9.335-9.379-9.317-24.544.04-33.901l22.667-22.667c9.373-9.373 24.569-9.373 33.941 0L285.475 239.03c9.373 9.372 9.373 24.568.001 33.941z"></path>
                              </svg>
                              <!-- <i class="fas fa-chevron-right"></i> -->
                           </a>
                        </div>
                     </div>
                  </div>
                  <div class="row rowpad20 last-article__items last-article__items--home">
                     <div class="content-article__anons-item col-lg-4 col-md-4 col-sm-6 col-xs-6">
                        <div class="content-article__anons-item__image relative">
                           <div class="content-article__anons-item__image__overlay"></div>
                           <a href="#kompensaciya-za-razrushennoe-imuschestvo/" title="Компенсация за разрушенное имущество"><img data-src="assets//data_resized/a/0/5/8/6/a058662200a2d803271fb7ceb921da2be9fe34d0.jpeg" alt="Компенсация за разрушенное имущество" class=" ls-is-cached lazyloaded" src="assets/a058662200a2d803271fb7ceb921da2be9fe34d0.jpeg"></a>
                        </div>
                        <div class="content-article__anons-item__info content-article__anons-item__info--home" data-height="list-article" data-height-sm="" data-height-xs="" style="height: 269px;">
                           <div data-height="list-article-descr" data-height-sm="" data-height-xs="" style="height: 151px;">
                              <div class="content-article__anons-item__name">
                                 <a href="#kompensaciya-za-razrushennoe-imuschestvo/">Компенсация за разрушенное имущество</a>
                              </div>
                              <div class="content-article__anons-item__anonse">
                                 <div> Сегодня достаточно актуален вопрос компенсации за разрушенное имущество, вызванное вооруженной агрессией России. Порядок компенсации предусмотрен ...</div>
                              </div>
                           </div>
                           <div class="content-article__anons-item__date">26 / 10 / 2023</div>
                        </div>
                     </div>
                     <div class="content-article__anons-item col-lg-4 col-md-4 col-sm-6 col-xs-6">
                        <div class="content-article__anons-item__image relative">
                           <div class="content-article__anons-item__image__overlay"></div>
                           <a href="#kak-komissirovatsya-vo-vremya-voennogo-polozheniya/" title="Как комиссироваться во время военного положения"><img data-src="assets//data_resized/a/f/2/8/9/af289d6c0d7fac476197611d09d9b6a06311f505.jpeg" alt="Как комиссироваться во время военного положения" class=" ls-is-cached lazyloaded" src="assets/af289d6c0d7fac476197611d09d9b6a06311f505.jpeg"></a>
                        </div>
                        <div class="content-article__anons-item__info content-article__anons-item__info--home" data-height="list-article" data-height-sm="" data-height-xs="" style="height: 269px;">
                           <div data-height="list-article-descr" data-height-sm="" data-height-xs="" style="height: 151px;">
                              <div class="content-article__anons-item__name">
                                 <a href="#kak-komissirovatsya-vo-vremya-voennogo-polozheniya/">Как комиссироваться во время военного положения</a>
                              </div>
                              <div class="content-article__anons-item__anonse">
                                 <div> В связи с полномасштабным вторжением Российской Федерации 24.02.2022 года, численность украинской армии выросла почти втрое по сравнению с 2014-20...</div>
                              </div>
                           </div>
                           <div class="content-article__anons-item__date">16 / 10 / 2023</div>
                        </div>
                     </div>
                     <div class="content-article__anons-item col-lg-4 col-md-4 col-sm-6 col-xs-6 hidden-sm hidden-xs">
                        <div class="content-article__anons-item__image relative">
                           <div class="content-article__anons-item__image__overlay"></div>
                           <a href="#rozpodil-mayna-pri-rozluchenni/" title="Раздел имущества при разводе"><img data-src="assets//data_resized/f/d/9/4/b/fd94b978517e8049f6568ce688e267eb692fbd5d.jpeg" alt="Раздел имущества при разводе" class=" ls-is-cached lazyloaded" src="assets/fd94b978517e8049f6568ce688e267eb692fbd5d.jpeg"></a>
                        </div>
                        <div class="content-article__anons-item__info content-article__anons-item__info--home" data-height="list-article" data-height-sm="" data-height-xs="" style="height: 269px;">
                           <div data-height="list-article-descr" data-height-sm="" data-height-xs="" style="height: 151px;">
                              <div class="content-article__anons-item__name">
                                 <a href="#rozpodil-mayna-pri-rozluchenni/">Раздел имущества при разводе</a>
                              </div>
                              <div class="content-article__anons-item__anonse">
                                 <div> С течением последних событий в Украине значительно изменились отношения между людьми в понимании друг друга. Общий стресс на фоне событий активизи...</div>
                              </div>
                           </div>
                           <div class="content-article__anons-item__date">12 / 10 / 2023</div>
                        </div>
                     </div>
                  </div>
                  <div class="row visible-xs">
                     <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
                        <div class="last-article__all-items">
                           <a href="#">
                              ВСІ СТАТТІ&nbsp;
                              <svg class="svg-inline--fa fa-chevron-right fa-w-10" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="chevron-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" data-fa-i2svg="">
                                 <path fill="currentColor" d="M285.476 272.971L91.132 467.314c-9.373 9.373-24.569 9.373-33.941 0l-22.667-22.667c-9.357-9.357-9.375-24.522-.04-33.901L188.505 256 34.484 101.255c-9.335-9.379-9.317-24.544.04-33.901l22.667-22.667c9.373-9.373 24.569-9.373 33.941 0L285.475 239.03c9.373 9.372 9.373 24.568.001 33.941z"></path>
                              </svg>
                              <!-- <i class="fas fa-chevron-right"></i> -->
                           </a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="container">
               <div class="clear"></div>
               <div class="mb50"></div>
               <div class="feedback-googlemap-form2__wrapper relative" data-height="feedback-height" data-height-sm="" style="height: 713px;">
                  <div id="block_67" class="feedback-googlemap-form2__inner feedback-googlemap-form2__inner--absolute">
                     <div class="container">
                        <div class="row rowpad20">
                           <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 relative">
                              <div class="h2__title">
                                 <div class="h2__icon">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                 </div>
                                 Контакты
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="feedback-googlemap-form feedback-googlemap-form2">
                        <div class="feedback-googlemap-form__container container">
                           <div class="row rowpad20">
                              <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                 <div class="feedback-googlemap-form__contact">
                                    <div data-height="feedback-form-height" data-height-sm="" style="height: 395px;">
                                       <div>
                                          <p class="contacts__title">Адрес</p>
                                          <div class="contacts__item">
                                             <p>Украина, Киев<br>
                                                ул. Василия Тютюнника, 37/1,&nbsp;оф. 102
                                             </p>
                                          </div>
                                          <p class="contacts__title">Телефон:</p>
                                          <div class="contacts__item contacts__item--phone">
                                             <p><a href="#">(068) 88 44 888</a> <a href="#">(viber,</a> <a href="#">telegram,</a> <a href="#">whatsapp)</a></p>
                                          </div>
                                          <p class="contacts__title">Режим работы:</p>
                                          <div class="contacts__item">
                                             <p>Пн-Пт: 9:00-18:00</p>
                                             <p>Сб-Вс: выходные</p>
                                          </div>
                                          <p class="contacts__title">E-mail</p>
                                          <div class="contacts__item">
                                             <p>info@gracers.com</p>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="form-group feedback-googlemap-form__btn">
                                       <div class="text-center">
                                          <div id="askQuestionBtn" class="cms__btn cms__btn--form" onclick="$('.feedback-googlemap-form__form').toggleClass('dnone');$('.feedback-googlemap-form__form').removeClass('feedback-googlemap-form__form--success');$(this).toggleClass('cms__btn--form-disable');">Получить консультацию</div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                 <div class="feedback-googlemap-form__form feedback-googlemap-form__form--active dnone">
                                    <div class="feedback-googlemap__form__close" onclick="$('.feedback-googlemap-form__form').addClass('dnone');$('.feedback-googlemap-form__form').removeClass('feedback-googlemap-form__form--success');$('#askQuestionBtn').removeClass('cms__btn--form-disable');"><span class="lnr lnr-cross"></span></div>
                                    <div class="feedback-googlemap__form" id="feedback_form">
                                       <form id="feedback_form67" method="post" action="spasibo.php" role="form" class="form-horizontal cms-form" data-toggle="validator" novalidate="true">
                                          <input type="hidden" name="form" value="block-submit">
                                          <input type="hidden" name="cat_id" value="23">
                                          <input type="hidden" name="url" value="/ru/glavnaya/">
                                          <input type="hidden" name="block_id" value="67">
                                          <input type="hidden" name="block_type" value="GooglemapForm2">
                                          <input type="hidden" name="action" value="addfback">
                                          <div data-height="feedback-form-height" data-height-sm="" style="height: 395px;">
                                             <div class="alert alert-info hidden" id="feedback_ok">Ваше сообщение отправлено!</div>
                                             <div class="feedback-googlemap__form__title">Задать вопрос</div>
                                             <div class="feedback-googlemap__form__message">Сотрудничество с нами - предоставит вам массу преимуществ.</div>
                                             <div id="block_67_errors">
                                                <div>
                                                </div>
                                             </div>
                                             <div>
                                                <div class="form-group">
                                                   <div class="col-sm-12">
                                                      <input type="text" name="feedback[name]" value="" class="form-control" required="" placeholder="Имя*">
                                                   </div>
                                                </div>
                                                <div class="form-group">
                                                   <div class="col-sm-12">
                                                      <input type="text" name="feedback[phone]" value="" class="form-control mobile" required="" placeholder="Телефон*" inputmode="text">
                                                   </div>
                                                </div>
                                                <div class="form-group">
                                                   <div class="col-sm-12">
                                                      <input type="email" name="feedback[email]" value="" class="form-control" placeholder="E-mail">
                                                   </div>
                                                </div>
                                                <div class="form-group">
                                                   <div class="col-sm-12">
                                                      <textarea name="feedback[comment]" class="form-control feedback-googlemap-form__textarea" required="" placeholder="Ваше сообщение"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <div class="form-group feedback-googlemap-form__btn">
                                             <div class="col-sm-12 text-center">
                                                <button type="submit" class="cms__btn cms__btn--form">Отправить</button>
                                             </div>
                                          </div>
                                       </form>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="feedback-googlemap__map" id="feedback-googlemap__map" data-height="feedback-height" data-height-sm="" style="height: 713px; position: relative; overflow: hidden;">
                     <div style="height: 100%; width: 100%; position: absolute; top: 0px; left: 0px; background-color: rgb(229, 227, 223);">
                        <div class="gm-style" style="position: absolute; z-index: 0; left: 0px; top: 0px; height: 100%; width: 100%; padding: 0px; border-width: 0px; margin: 0px;">
                           <div><button draggable="false" aria-label="Keyboard shortcuts" title="Keyboard shortcuts" type="button" style="background: none transparent; display: block; border: none; margin: 0px; padding: 0px; text-transform: none; appearance: none; position: absolute; cursor: pointer; user-select: none; z-index: 1000002; outline-offset: 3px; right: 0px; bottom: 0px; transform: translateX(100%);"></button></div>
                           <div tabindex="0" aria-label="Map" aria-roledescription="map" role="region" aria-describedby="D07032B1-6CCC-474E-A94E-C01DA6C91DF3" style="position: absolute; z-index: 0; left: 0px; top: 0px; height: 100%; width: 100%; padding: 0px; border-width: 0px; margin: 0px; cursor: url(&quot;openhand_8_8.cur.bmp&quot;), default; touch-action: pan-x pan-y;">
                              <div style="z-index: 1; position: absolute; left: 50%; top: 50%; width: 100%; will-change: transform; transform: translate(0px, 0px);">
                                 <div style="position: absolute; left: 0px; top: 0px; z-index: 100; width: 100%;">
                                    <div style="position: absolute; left: 0px; top: 0px; z-index: 0;">
                                       <div style="position: absolute; z-index: 987; transform: matrix(1, 0, 0, 1, -109, -35);">
                                          <div style="position: absolute; left: 0px; top: 0px; width: 256px; height: 256px;">
                                             <div style="width: 256px; height: 256px;"></div>
                                          </div>
                                          <div style="position: absolute; left: -256px; top: 0px; width: 256px; height: 256px;">
                                             <div style="width: 256px; height: 256px;"></div>
                                          </div>
                                          <div style="position: absolute; left: -256px; top: -256px; width: 256px; height: 256px;">
                                             <div style="width: 256px; height: 256px;"></div>
                                          </div>
                                          <div style="position: absolute; left: 0px; top: -256px; width: 256px; height: 256px;">
                                             <div style="width: 256px; height: 256px;"></div>
                                          </div>
                                          <div style="position: absolute; left: 256px; top: -256px; width: 256px; height: 256px;">
                                             <div style="width: 256px; height: 256px;"></div>
                                          </div>
                                          <div style="position: absolute; left: 256px; top: 0px; width: 256px; height: 256px;">
                                             <div style="width: 256px; height: 256px;"></div>
                                          </div>
                                          <div style="position: absolute; left: 256px; top: 256px; width: 256px; height: 256px;">
                                             <div style="width: 256px; height: 256px;"></div>
                                          </div>
                                          <div style="position: absolute; left: 0px; top: 256px; width: 256px; height: 256px;">
                                             <div style="width: 256px; height: 256px;"></div>
                                          </div>
                                          <div style="position: absolute; left: -256px; top: 256px; width: 256px; height: 256px;">
                                             <div style="width: 256px; height: 256px;"></div>
                                          </div>
                                          <div style="position: absolute; left: -512px; top: 256px; width: 256px; height: 256px;">
                                             <div style="width: 256px; height: 256px;"></div>
                                          </div>
                                          <div style="position: absolute; left: -512px; top: 0px; width: 256px; height: 256px;">
                                             <div style="width: 256px; height: 256px;"></div>
                                          </div>
                                          <div style="position: absolute; left: -512px; top: -256px; width: 256px; height: 256px;">
                                             <div style="width: 256px; height: 256px;"></div>
                                          </div>
                                          <div style="position: absolute; left: -512px; top: -512px; width: 256px; height: 256px;">
                                             <div style="width: 256px; height: 256px;"></div>
                                          </div>
                                          <div style="position: absolute; left: -256px; top: -512px; width: 256px; height: 256px;">
                                             <div style="width: 256px; height: 256px;"></div>
                                          </div>
                                          <div style="position: absolute; left: 0px; top: -512px; width: 256px; height: 256px;">
                                             <div style="width: 256px; height: 256px;"></div>
                                          </div>
                                          <div style="position: absolute; left: 256px; top: -512px; width: 256px; height: 256px;">
                                             <div style="width: 256px; height: 256px;"></div>
                                          </div>
                                          <div style="position: absolute; left: 512px; top: -512px; width: 256px; height: 256px;">
                                             <div style="width: 256px; height: 256px;"></div>
                                          </div>
                                          <div style="position: absolute; left: 512px; top: -256px; width: 256px; height: 256px;">
                                             <div style="width: 256px; height: 256px;"></div>
                                          </div>
                                          <div style="position: absolute; left: 512px; top: 0px; width: 256px; height: 256px;">
                                             <div style="width: 256px; height: 256px;"></div>
                                          </div>
                                          <div style="position: absolute; left: 512px; top: 256px; width: 256px; height: 256px;">
                                             <div style="width: 256px; height: 256px;"></div>
                                          </div>
                                          <div style="position: absolute; left: -768px; top: 256px; width: 256px; height: 256px;">
                                             <div style="width: 256px; height: 256px;"></div>
                                          </div>
                                          <div style="position: absolute; left: -768px; top: 0px; width: 256px; height: 256px;">
                                             <div style="width: 256px; height: 256px;"></div>
                                          </div>
                                          <div style="position: absolute; left: -768px; top: -256px; width: 256px; height: 256px;">
                                             <div style="width: 256px; height: 256px;"></div>
                                          </div>
                                          <div style="position: absolute; left: -768px; top: -512px; width: 256px; height: 256px;">
                                             <div style="width: 256px; height: 256px;"></div>
                                          </div>
                                          <div style="position: absolute; left: 768px; top: -512px; width: 256px; height: 256px;">
                                             <div style="width: 256px; height: 256px;"></div>
                                          </div>
                                          <div style="position: absolute; left: 768px; top: -256px; width: 256px; height: 256px;">
                                             <div style="width: 256px; height: 256px;"></div>
                                          </div>
                                          <div style="position: absolute; left: 768px; top: 0px; width: 256px; height: 256px;">
                                             <div style="width: 256px; height: 256px;"></div>
                                          </div>
                                          <div style="position: absolute; left: 768px; top: 256px; width: 256px; height: 256px;">
                                             <div style="width: 256px; height: 256px;"></div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div style="position: absolute; left: 0px; top: 0px; z-index: 101; width: 100%;"></div>
                                 <div style="position: absolute; left: 0px; top: 0px; z-index: 102; width: 100%;"></div>
                                 <div style="position: absolute; left: 0px; top: 0px; z-index: 103; width: 100%;">
                                    <div style="position: absolute; left: 0px; top: 0px; z-index: -1;">
                                       <div style="position: absolute; z-index: 987; transform: matrix(1, 0, 0, 1, -109, -35);">
                                          <div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: 0px; top: 0px;"></div>
                                          <div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: -256px; top: 0px;"></div>
                                          <div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: -256px; top: -256px;"></div>
                                          <div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: 0px; top: -256px;"></div>
                                          <div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: 256px; top: -256px;"></div>
                                          <div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: 256px; top: 0px;"></div>
                                          <div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: 256px; top: 256px;"></div>
                                          <div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: 0px; top: 256px;"></div>
                                          <div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: -256px; top: 256px;"></div>
                                          <div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: -512px; top: 256px;"></div>
                                          <div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: -512px; top: 0px;"></div>
                                          <div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: -512px; top: -256px;"></div>
                                          <div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: -512px; top: -512px;"></div>
                                          <div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: -256px; top: -512px;"></div>
                                          <div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: 0px; top: -512px;"></div>
                                          <div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: 256px; top: -512px;"></div>
                                          <div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: 512px; top: -512px;"></div>
                                          <div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: 512px; top: -256px;"></div>
                                          <div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: 512px; top: 0px;"></div>
                                          <div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: 512px; top: 256px;"></div>
                                          <div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: -768px; top: 256px;"></div>
                                          <div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: -768px; top: 0px;"></div>
                                          <div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: -768px; top: -256px;"></div>
                                          <div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: -768px; top: -512px;"></div>
                                          <div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: 768px; top: -512px;"></div>
                                          <div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: 768px; top: -256px;"></div>
                                          <div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: 768px; top: 0px;"></div>
                                          <div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: 768px; top: 256px;"></div>
                                       </div>
                                    </div>
                                    <div style="width: 32px; height: 48px; overflow: hidden; position: absolute; left: -485px; top: -6px; z-index: 42;"><img alt="" src="assets/icon__map.png" draggable="false" style="position: absolute; left: 0px; top: 0px; user-select: none; width: 32px; height: 48px; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                 </div>
                                 <div style="position: absolute; left: 0px; top: 0px; z-index: 0;">
                                    <div style="position: absolute; z-index: 987; transform: matrix(1, 0, 0, 1, -109, -35);">
                                       <div style="position: absolute; left: 0px; top: 0px; width: 256px; height: 256px; transition: opacity 200ms linear 0s;"><img draggable="false" alt="" role="presentation" src="assets/vt.png" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                       <div style="position: absolute; left: -256px; top: 0px; width: 256px; height: 256px; transition: opacity 200ms linear 0s;"><img draggable="false" alt="" role="presentation" src="assets/vt-1.png" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                       <div style="position: absolute; left: -256px; top: -256px; width: 256px; height: 256px; transition: opacity 200ms linear 0s;"><img draggable="false" alt="" role="presentation" src="assets/vt-2.png" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                       <div style="position: absolute; left: 0px; top: -256px; width: 256px; height: 256px; transition: opacity 200ms linear 0s;"><img draggable="false" alt="" role="presentation" src="assets/vt-3.png" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                       <div style="position: absolute; left: 256px; top: -256px; width: 256px; height: 256px; transition: opacity 200ms linear 0s;"><img draggable="false" alt="" role="presentation" src="assets/vt-4.png" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                       <div style="position: absolute; left: 256px; top: 0px; width: 256px; height: 256px; transition: opacity 200ms linear 0s;"><img draggable="false" alt="" role="presentation" src="assets/vt-5.png" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                       <div style="position: absolute; left: 256px; top: 256px; width: 256px; height: 256px; transition: opacity 200ms linear 0s;"><img draggable="false" alt="" role="presentation" src="assets/vt-6.png" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                       <div style="position: absolute; left: 0px; top: 256px; width: 256px; height: 256px; transition: opacity 200ms linear 0s;"><img draggable="false" alt="" role="presentation" src="assets/vt-7.png" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                       <div style="position: absolute; left: -256px; top: 256px; width: 256px; height: 256px; transition: opacity 200ms linear 0s;"><img draggable="false" alt="" role="presentation" src="assets/vt-8.png" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                       <div style="position: absolute; left: -512px; top: 256px; width: 256px; height: 256px; transition: opacity 200ms linear 0s;"><img draggable="false" alt="" role="presentation" src="assets/vt-9.png" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                       <div style="position: absolute; left: -512px; top: 0px; width: 256px; height: 256px; transition: opacity 200ms linear 0s;"><img draggable="false" alt="" role="presentation" src="assets/vt-10.png" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                       <div style="position: absolute; left: -512px; top: -256px; width: 256px; height: 256px; transition: opacity 200ms linear 0s;"><img draggable="false" alt="" role="presentation" src="assets/vt-11.png" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                       <div style="position: absolute; left: -512px; top: -512px; width: 256px; height: 256px; transition: opacity 200ms linear 0s;"><img draggable="false" alt="" role="presentation" src="assets/vt-12.png" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                       <div style="position: absolute; left: -256px; top: -512px; width: 256px; height: 256px; transition: opacity 200ms linear 0s;"><img draggable="false" alt="" role="presentation" src="assets/vt-13.png" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                       <div style="position: absolute; left: 0px; top: -512px; width: 256px; height: 256px; transition: opacity 200ms linear 0s;"><img draggable="false" alt="" role="presentation" src="assets/vt-14.png" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                       <div style="position: absolute; left: 256px; top: -512px; width: 256px; height: 256px; transition: opacity 200ms linear 0s;"><img draggable="false" alt="" role="presentation" src="assets/vt-15.png" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                       <div style="position: absolute; left: -768px; top: 256px; width: 256px; height: 256px; transition: opacity 200ms linear 0s;"><img draggable="false" alt="" role="presentation" src="assets/vt-16.png" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                       <div style="position: absolute; left: -768px; top: -256px; width: 256px; height: 256px; transition: opacity 200ms linear 0s;"><img draggable="false" alt="" role="presentation" src="assets/vt-17.png" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                       <div style="position: absolute; left: -768px; top: 0px; width: 256px; height: 256px; transition: opacity 200ms linear 0s;"><img draggable="false" alt="" role="presentation" src="assets/vt-18.png" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                       <div style="position: absolute; left: -768px; top: -512px; width: 256px; height: 256px; transition: opacity 200ms linear 0s;"><img draggable="false" alt="" role="presentation" src="assets/vt-19.png" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                       <div style="position: absolute; left: 768px; top: 0px; width: 256px; height: 256px; transition: opacity 200ms linear 0s;"><img draggable="false" alt="" role="presentation" src="assets/vt-20.png" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                       <div style="position: absolute; left: 768px; top: -256px; width: 256px; height: 256px; transition: opacity 200ms linear 0s;"><img draggable="false" alt="" role="presentation" src="assets/vt-21.png" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                       <div style="position: absolute; left: 768px; top: -512px; width: 256px; height: 256px; transition: opacity 200ms linear 0s;"><img draggable="false" alt="" role="presentation" src="assets/vt-22.png" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                       <div style="position: absolute; left: 512px; top: -512px; width: 256px; height: 256px; transition: opacity 200ms linear 0s;"><img draggable="false" alt="" role="presentation" src="assets/vt-23.png" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                       <div style="position: absolute; left: 512px; top: -256px; width: 256px; height: 256px; transition: opacity 200ms linear 0s;"><img draggable="false" alt="" role="presentation" src="assets/vt-24.png" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                       <div style="position: absolute; left: 512px; top: 256px; width: 256px; height: 256px; transition: opacity 200ms linear 0s;"><img draggable="false" alt="" role="presentation" src="assets/vt-25.png" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                       <div style="position: absolute; left: 512px; top: 0px; width: 256px; height: 256px; transition: opacity 200ms linear 0s;"><img draggable="false" alt="" role="presentation" src="assets/vt-26.png" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                       <div style="position: absolute; left: 768px; top: 256px; width: 256px; height: 256px; transition: opacity 200ms linear 0s;"><img draggable="false" alt="" role="presentation" src="assets/vt-27.png" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                    </div>
                                 </div>
                              </div>
                              <div style="z-index: 3; position: absolute; height: 100%; width: 100%; padding: 0px; border-width: 0px; margin: 0px; left: 0px; top: 0px; touch-action: pan-x pan-y;">
                                 <div style="z-index: 4; position: absolute; left: 50%; top: 50%; width: 100%; will-change: transform; transform: translate(0px, 0px);">
                                    <div style="position: absolute; left: 0px; top: 0px; z-index: 104; width: 100%;"></div>
                                    <div style="position: absolute; left: 0px; top: 0px; z-index: 105; width: 100%;"></div>
                                    <div style="position: absolute; left: 0px; top: 0px; z-index: 106; width: 100%;">
                                       <span id="95C676F1-66B7-4C4F-AB54-F91814DD3E63" style="display: none;">To navigate, press the arrow keys.</span>
                                       <div title="" tabindex="-1" style="width: 32px; height: 48px; overflow: hidden; position: absolute; cursor: pointer; touch-action: none; left: -485px; top: -6px; z-index: 42;"><img alt="" src="assets/transparent.png" draggable="false" style="width: 32px; height: 48px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div>
                                    </div>
                                    <div style="position: absolute; left: 0px; top: 0px; z-index: 107; width: 100%;"></div>
                                 </div>
                              </div>
                              <div class="gm-style-moc" style="z-index: 4; position: absolute; height: 100%; width: 100%; padding: 0px; border-width: 0px; margin: 0px; left: 0px; top: 0px; opacity: 0;">
                                 <p class="gm-style-mot"></p>
                              </div>
                              <div class="LGLeeN-keyboard-shortcuts-view" id="D07032B1-6CCC-474E-A94E-C01DA6C91DF3" style="display: none;">
                                 <table>
                                    <tbody>
                                       <tr>
                                          <td><kbd aria-label="Left arrow">←</kbd></td>
                                          <td aria-label="Move left.">Move left</td>
                                       </tr>
                                       <tr>
                                          <td><kbd aria-label="Right arrow">→</kbd></td>
                                          <td aria-label="Move right.">Move right</td>
                                       </tr>
                                       <tr>
                                          <td><kbd aria-label="Up arrow">↑</kbd></td>
                                          <td aria-label="Move up.">Move up</td>
                                       </tr>
                                       <tr>
                                          <td><kbd aria-label="Down arrow">↓</kbd></td>
                                          <td aria-label="Move down.">Move down</td>
                                       </tr>
                                       <tr>
                                          <td><kbd>+</kbd></td>
                                          <td aria-label="Zoom in.">Zoom in</td>
                                       </tr>
                                       <tr>
                                          <td><kbd>-</kbd></td>
                                          <td aria-label="Zoom out.">Zoom out</td>
                                       </tr>
                                       <tr>
                                          <td><kbd>Home</kbd></td>
                                          <td aria-label="Jump left by 75%.">Jump left by 75%</td>
                                       </tr>
                                       <tr>
                                          <td><kbd>End</kbd></td>
                                          <td aria-label="Jump right by 75%.">Jump right by 75%</td>
                                       </tr>
                                       <tr>
                                          <td><kbd>Page Up</kbd></td>
                                          <td aria-label="Jump up by 75%.">Jump up by 75%</td>
                                       </tr>
                                       <tr>
                                          <td><kbd>Page Down</kbd></td>
                                          <td aria-label="Jump down by 75%.">Jump down by 75%</td>
                                       </tr>
                                    </tbody>
                                 </table>
                              </div>
                           </div>
                           <div style="pointer-events: none; width: 100%; height: 100%; box-sizing: border-box; position: absolute; z-index: 1000002; opacity: 0; border: 2px solid rgb(26, 115, 232);"></div>
                           <div></div>
                           <div></div>
                           <div></div>
                           <div></div>
                           <div><button draggable="false" aria-label="Toggle fullscreen view" title="Toggle fullscreen view" type="button" aria-pressed="false" class="gm-control-active gm-fullscreen-control" style="background: none rgb(255, 255, 255); border: 0px; margin: 10px; padding: 0px; text-transform: none; appearance: none; position: absolute; cursor: pointer; user-select: none; border-radius: 2px; height: 40px; width: 40px; box-shadow: rgba(0, 0, 0, 0.3) 0px 1px 4px -1px; overflow: hidden; top: 0px; right: 0px;"><img src="assets/9a91c387b5af040ea1593997527c91f31258aa77.svg" alt="" style="height: 18px; width: 18px;"><img src="assets/b53688f60120f534170affcfbc23e428486f4ea8.svg" alt="" style="height: 18px; width: 18px;"><img src="assets/189c8a97bb5c749b49fa5d7993f04882e023fafd.svg" alt="" style="height: 18px; width: 18px;"></button></div>
                           <div></div>
                           <div></div>
                           <div></div>
                           <div></div>
                           <div>
                              <div class="gmnoprint gm-bundled-control gm-bundled-control-on-bottom" draggable="false" data-control-width="40" data-control-height="153" style="margin: 10px; user-select: none; position: absolute; bottom: 167px; right: 40px;">
                                 <div class="gmnoprint" data-control-width="40" data-control-height="40" style="display: none; position: absolute;">
                                    <div style="background-color: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.3) 0px 1px 4px -1px; border-radius: 2px; width: 40px; height: 40px;">
                                       <button draggable="false" aria-label="Rotate map clockwise" title="Rotate map clockwise" type="button" class="gm-control-active" style="background: none; display: none; border: 0px; margin: 0px; padding: 0px; text-transform: none; appearance: none; position: relative; cursor: pointer; user-select: none; left: 0px; top: 0px; overflow: hidden; width: 40px; height: 40px;"><img alt="" src="assets/307727718a094e1c7b841513e78f7308f7fb0ca9.svg" style="width: 20px; height: 20px;"><img alt="" src="assets/093a96f5d960fb8f6f8a2d37b327b23e054e76c1.svg" style="width: 20px; height: 20px;"><img alt="" src="assets/33ea66baf74e8030f166bf2e9ff6168b77793d53.svg" style="width: 20px; height: 20px;"></button>
                                       <div style="position: relative; overflow: hidden; width: 30px; height: 1px; margin: 0px 5px; background-color: rgb(230, 230, 230); display: none;"></div>
                                       <button draggable="false" aria-label="Rotate map counterclockwise" title="Rotate map counterclockwise" type="button" class="gm-control-active" style="background: none; display: none; border: 0px; margin: 0px; padding: 0px; text-transform: none; appearance: none; position: relative; cursor: pointer; user-select: none; left: 0px; top: 0px; overflow: hidden; width: 40px; height: 40px; transform: scaleX(-1);"><img alt="" src="assets/307727718a094e1c7b841513e78f7308f7fb0ca9.svg" style="width: 20px; height: 20px;"><img alt="" src="assets/093a96f5d960fb8f6f8a2d37b327b23e054e76c1.svg" style="width: 20px; height: 20px;"><img alt="" src="assets/33ea66baf74e8030f166bf2e9ff6168b77793d53.svg" style="width: 20px; height: 20px;"></button>
                                       <div style="position: relative; overflow: hidden; width: 30px; height: 1px; margin: 0px 5px; background-color: rgb(230, 230, 230); display: none;"></div>
                                       <button draggable="false" aria-label="Tilt map" title="Tilt map" type="button" class="gm-tilt gm-control-active" style="background: none; display: block; border: 0px; margin: 0px; padding: 0px; text-transform: none; appearance: none; position: relative; cursor: pointer; user-select: none; top: 0px; left: 0px; overflow: hidden; width: 40px; height: 40px;"><img alt="" src="assets/6068af43d777128e4a09c89910a6c773d522fdfa.svg" style="width: 18px;"><img alt="" src="assets/de762194f94b36483b12502229e82c357334e5e6.svg" style="width: 18px;"><img alt="" src="assets/347115e75c29fea098318edbd38c12d15c367df7.svg" style="width: 18px;"></button>
                                    </div>
                                 </div>
                                 <button draggable="false" aria-label="Drag Pegman onto the map to open Street View" title="Drag Pegman onto the map to open Street View" type="button" class="gm-svpc" dir="ltr" data-control-width="40" data-control-height="40" style="background: rgb(255, 255, 255); border: 0px; margin: 0px; padding: 0px; text-transform: none; appearance: none; position: absolute; cursor: url(&quot;openhand_8_8.cur.bmp&quot;), default; user-select: none; --pegman-scaleX: 1; box-shadow: rgba(0, 0, 0, 0.3) 0px 1px 4px -1px; border-radius: 2px; width: 40px; height: 40px; touch-action: none; left: 0px; top: 0px;">
                                    <div style="position: absolute; left: 50%; top: 50%; transform: scaleX(var(--pegman-scaleX));"><img src="assets/b0e71c285bbf80a1dc52a0ef0f9c67ab9cf06f9c.svg" alt="Street View Pegman Control" style="height: 30px; width: 30px; position: absolute; transform: translate(-50%, -50%); pointer-events: none;"><img src="assets/9bb3da276bf74469bc4c61de00d866966b6ae0dc.svg" alt="Pegman is on top of the Map" style="height: 30px; width: 30px; position: absolute; transform: translate(-50%, -50%); pointer-events: none; display: none;"><img alt="Street View Pegman Control" src="assets/6a853c54871430e1e276e3199c391f91e630697c.svg" style="display: none; height: 40px; width: 40px; position: absolute; transform: translate(-60%, -45%); pointer-events: none;"></div>
                                 </button>
                                 <div class="gmnoprint" data-control-width="40" data-control-height="81" style="position: absolute; left: 0px; top: 72px;">
                                    <div draggable="false" style="user-select: none; box-shadow: rgba(0, 0, 0, 0.3) 0px 1px 4px -1px; border-radius: 2px; cursor: pointer; background-color: rgb(255, 255, 255); width: 40px; height: 81px;">
                                       <button draggable="false" aria-label="Zoom in" title="Zoom in" type="button" class="gm-control-active" style="background: none; display: block; border: 0px; margin: 0px; padding: 0px; text-transform: none; appearance: none; position: relative; cursor: pointer; user-select: none; overflow: hidden; width: 40px; height: 40px; top: 0px; left: 0px;"><img src="assets/0c03e2f68c34048f1ae9e34df0da26fe66076841.svg" alt="" style="height: 18px; width: 18px;"><img src="assets/8c6ff9258dfdb8cea73e1e43ea7178f044b763b9.svg" alt="" style="height: 18px; width: 18px;"><img src="assets/c561bd899f92d8ae1bb1f17039e9eb8ab93a70cb.svg" alt="" style="height: 18px; width: 18px;"><img src="assets/1fc739251896417ba70206cace6922a9db2ee417.svg" alt="" style="height: 18px; width: 18px;"></button>
                                       <div style="position: relative; overflow: hidden; width: 30px; height: 1px; margin: 0px 5px; background-color: rgb(230, 230, 230); top: 0px;"></div>
                                       <button draggable="false" aria-label="Zoom out" title="Zoom out" type="button" class="gm-control-active" style="background: none; display: block; border: 0px; margin: 0px; padding: 0px; text-transform: none; appearance: none; position: relative; cursor: pointer; user-select: none; overflow: hidden; width: 40px; height: 40px; top: 0px; left: 0px;"><img src="assets/4a3b3ec33fa669d3194f454c76a772358f51e965.svg" alt="" style="height: 18px; width: 18px;"><img src="assets/5008a61f6521a94969b2fc1272e595e327c3ec6d.svg" alt="" style="height: 18px; width: 18px;"><img src="assets/9f9f19af37b524a87f8925b2fb9a64947306a634.svg" alt="" style="height: 18px; width: 18px;"><img src="assets/a347b6be6959d719b3239e466b3e2bb38eb0115b.svg" alt="" style="height: 18px; width: 18px;"></button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div>
                              <div style="margin: 0px 5px; z-index: 1000000; position: absolute; left: 0px; bottom: 0px;">
                                 <a target="_blank" rel="noopener" title="Open this area in Google Maps (opens a new window)" aria-label="Open this area in Google Maps (opens a new window)" href="https://maps.google.com/maps?ll=50.425682,30.604708&amp;z=13&amp;hl=en-US&amp;gl=US&amp;mapclient=apiv3" style="display: inline;">
                                    <div style="width: 66px; height: 26px;"><img alt="Google" src="assets/f549a9c56300e4aeff48113071d7def49701231a.svg" draggable="false" style="position: absolute; left: 0px; top: 0px; width: 66px; height: 26px; user-select: none; border: 0px; padding: 0px; margin: 0px;"></div>
                                 </a>
                              </div>
                           </div>
                           <div></div>
                           <div>
                              <div style="display: inline-flex; position: absolute; right: 0px; bottom: 0px;">
                                 <div class="gmnoprint" style="z-index: 1000001;">
                                    <div draggable="false" class="gm-style-cc" style="user-select: none; position: relative; height: 14px; line-height: 14px;">
                                       <div style="opacity: 0.7; width: 100%; height: 100%; position: absolute;">
                                          <div style="width: 1px;"></div>
                                          <div style="background-color: rgb(245, 245, 245); width: auto; height: 100%; margin-left: 1px;"></div>
                                       </div>
                                       <div style="position: relative; padding-right: 6px; padding-left: 6px; box-sizing: border-box; font-family: Roboto, Arial, sans-serif; font-size: 10px; color: rgb(0, 0, 0); white-space: nowrap; direction: ltr; text-align: right; vertical-align: middle; display: inline-block;"><button draggable="false" aria-label="Keyboard shortcuts" title="Keyboard shortcuts" type="button" style="background: none; display: inline-block; border: 0px; margin: 0px; padding: 0px; text-transform: none; appearance: none; position: relative; cursor: pointer; user-select: none; color: rgb(0, 0, 0); font-family: inherit; line-height: inherit;">Keyboard shortcuts</button></div>
                                    </div>
                                 </div>
                                 <div class="gmnoprint" style="z-index: 1000001;">
                                    <div draggable="false" class="gm-style-cc" style="user-select: none; position: relative; height: 14px; line-height: 14px;">
                                       <div style="opacity: 0.7; width: 100%; height: 100%; position: absolute;">
                                          <div style="width: 1px;"></div>
                                          <div style="background-color: rgb(245, 245, 245); width: auto; height: 100%; margin-left: 1px;"></div>
                                       </div>
                                       <div style="position: relative; padding-right: 6px; padding-left: 6px; box-sizing: border-box; font-family: Roboto, Arial, sans-serif; font-size: 10px; color: rgb(0, 0, 0); white-space: nowrap; direction: ltr; text-align: right; vertical-align: middle; display: inline-block;"><button draggable="false" aria-label="Map Data" title="Map Data" type="button" style="background: none; border: 0px; margin: 0px; padding: 0px; text-transform: none; appearance: none; position: relative; cursor: pointer; user-select: none; color: rgb(0, 0, 0); font-family: inherit; line-height: inherit; display: none;">Map Data</button><span style="">Map data ©2023 Google</span></div>
                                    </div>
                                 </div>
                                 <div class="gmnoscreen">
                                    <div style="font-family: Roboto, Arial, sans-serif; font-size: 11px; color: rgb(0, 0, 0); direction: ltr; text-align: right; background-color: rgb(245, 245, 245);">Map data ©2023 Google</div>
                                 </div>
                                 <button draggable="false" aria-label="Map Scale: 500 m per 41 pixels" title="Map Scale: 500 m per 41 pixels" type="button" class="gm-style-cc" aria-describedby="BB31BA4B-C8DC-43A5-87C7-60829D7AFBFC" style="background: none; display: none; border: 0px; margin: 0px; padding: 0px; text-transform: none; appearance: none; position: relative; cursor: pointer; user-select: none; height: 14px; line-height: 14px;">
                                    <div style="opacity: 0.7; width: 100%; height: 100%; position: absolute;">
                                       <div style="width: 1px;"></div>
                                       <div style="background-color: rgb(245, 245, 245); width: auto; height: 100%; margin-left: 1px;"></div>
                                    </div>
                                    <div style="position: relative; padding-right: 6px; padding-left: 6px; box-sizing: border-box; font-family: Roboto, Arial, sans-serif; font-size: 10px; color: rgb(0, 0, 0); white-space: nowrap; direction: ltr; text-align: right; vertical-align: middle; display: inline-block;">
                                       <span>500 m&nbsp;</span>
                                       <div style="position: relative; display: inline-block; height: 8px; bottom: -1px; width: 45px;">
                                          <div style="width: 100%; height: 4px; position: absolute; left: 0px; top: 0px;"></div>
                                          <div style="width: 4px; height: 8px; left: 0px; top: 0px; background-color: rgb(255, 255, 255);"></div>
                                          <div style="width: 4px; height: 8px; position: absolute; background-color: rgb(255, 255, 255); right: 0px; bottom: 0px;"></div>
                                          <div style="position: absolute; background-color: rgb(102, 102, 102); height: 2px; left: 1px; bottom: 1px; right: 1px;"></div>
                                          <div style="position: absolute; width: 2px; height: 6px; left: 1px; top: 1px; background-color: rgb(102, 102, 102);"></div>
                                          <div style="width: 2px; height: 6px; position: absolute; background-color: rgb(102, 102, 102); bottom: 1px; right: 1px;"></div>
                                       </div>
                                    </div>
                                    <span id="BB31BA4B-C8DC-43A5-87C7-60829D7AFBFC" style="display: none;">Click to toggle between metric and imperial units</span>
                                 </button>
                                 <div class="gmnoprint gm-style-cc" draggable="false" style="z-index: 1000001; user-select: none; position: relative; height: 14px; line-height: 14px;">
                                    <div style="opacity: 0.7; width: 100%; height: 100%; position: absolute;">
                                       <div style="width: 1px;"></div>
                                       <div style="background-color: rgb(245, 245, 245); width: auto; height: 100%; margin-left: 1px;"></div>
                                    </div>
                                    <div style="position: relative; padding-right: 6px; padding-left: 6px; box-sizing: border-box; font-family: Roboto, Arial, sans-serif; font-size: 10px; color: rgb(0, 0, 0); white-space: nowrap; direction: ltr; text-align: right; vertical-align: middle; display: inline-block;"><a href="https://www.google.com/intl/en-US_US/help/terms_maps.html" target="_blank" rel="noopener" style="text-decoration: none; cursor: pointer; color: rgb(0, 0, 0);">Terms</a></div>
                                 </div>
                                 <div draggable="false" class="gm-style-cc" style="user-select: none; position: relative; height: 14px; line-height: 14px; display: none;">
                                    <div style="opacity: 0.7; width: 100%; height: 100%; position: absolute;">
                                       <div style="width: 1px;"></div>
                                       <div style="background-color: rgb(245, 245, 245); width: auto; height: 100%; margin-left: 1px;"></div>
                                    </div>
                                    <div style="position: relative; padding-right: 6px; padding-left: 6px; box-sizing: border-box; font-family: Roboto, Arial, sans-serif; font-size: 10px; color: rgb(0, 0, 0); white-space: nowrap; direction: ltr; text-align: right; vertical-align: middle; display: inline-block;"><a target="_blank" rel="noopener" title="Report errors in the road map or imagery to Google" dir="ltr" href="https://www.google.com/maps/@50.425682,30.604708,13z/data=!10m1!1e1!12b1?source=apiv3&amp;rapsrc=apiv3" style="font-family: Roboto, Arial, sans-serif; font-size: 10px; color: rgb(0, 0, 0); text-decoration: none; position: relative;">Report a map error</a></div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <script>
                     function initMap() {
                         map = new google.maps.Map(document.getElementById('feedback-googlemap__map'), {
                             zoom: 13,
                             center: new google.maps.LatLng(50.425682,30.604708),
                             mapTypeId: 'roadmap',
                             mapTypeControl: false
                         });
                     
                                     var styledMapType = new google.maps.StyledMapType([
                     {
                         "featureType": "all",
                         "elementType": "all",
                         "stylers": [
                             {
                                 "lightness": "29"
                             },
                             {
                                 "invert_lightness": true
                             },
                             {
                                 "hue": "#008fff"
                             },
                             {
                                 "saturation": "-73"
                             }
                         ]
                     },
                     {
                         "featureType": "all",
                         "elementType": "labels",
                         "stylers": [
                             {
                                 "saturation": "-72"
                             }
                         ]
                     },
                     {
                         "featureType": "administrative",
                         "elementType": "all",
                         "stylers": [
                             {
                                 "lightness": "32"
                             },
                             {
                                 "weight": "0.42"
                             }
                         ]
                     },
                     {
                         "featureType": "administrative",
                         "elementType": "labels",
                         "stylers": [
                             {
                                 "visibility": "on"
                             },
                             {
                                 "lightness": "-53"
                             },
                             {
                                 "saturation": "-66"
                             }
                         ]
                     },
                     {
                         "featureType": "landscape",
                         "elementType": "all",
                         "stylers": [
                             {
                                 "lightness": "-86"
                             },
                             {
                                 "gamma": "1.13"
                             }
                         ]
                     },
                     {
                         "featureType": "landscape",
                         "elementType": "geometry.fill",
                         "stylers": [
                             {
                                 "hue": "#006dff"
                             },
                             {
                                 "lightness": "4"
                             },
                             {
                                 "gamma": "1.44"
                             },
                             {
                                 "saturation": "-67"
                             }
                         ]
                     },
                     {
                         "featureType": "landscape",
                         "elementType": "geometry.stroke",
                         "stylers": [
                             {
                                 "lightness": "5"
                             }
                         ]
                     },
                     {
                         "featureType": "landscape",
                         "elementType": "labels.text.fill",
                         "stylers": [
                             {
                                 "visibility": "off"
                             }
                         ]
                     },
                     {
                         "featureType": "poi",
                         "elementType": "all",
                         "stylers": [
                             {
                                 "visibility": "off"
                             }
                         ]
                     },
                     {
                         "featureType": "poi",
                         "elementType": "labels.text.fill",
                         "stylers": [
                             {
                                 "weight": "0.84"
                             },
                             {
                                 "gamma": "0.5"
                             }
                         ]
                     },
                     {
                         "featureType": "poi",
                         "elementType": "labels.text.stroke",
                         "stylers": [
                             {
                                 "visibility": "off"
                             },
                             {
                                 "weight": "0.79"
                             },
                             {
                                 "gamma": "0.5"
                             }
                         ]
                     },
                     {
                         "featureType": "road",
                         "elementType": "all",
                         "stylers": [
                             {
                                 "visibility": "simplified"
                             },
                             {
                                 "lightness": "-78"
                             },
                             {
                                 "saturation": "-91"
                             }
                         ]
                     },
                     {
                         "featureType": "road",
                         "elementType": "labels.text",
                         "stylers": [
                             {
                                 "color": "#ffffff"
                             },
                             {
                                 "lightness": "-69"
                             }
                         ]
                     },
                     {
                         "featureType": "road.highway",
                         "elementType": "geometry.fill",
                         "stylers": [
                             {
                                 "lightness": "5"
                             }
                         ]
                     },
                     {
                         "featureType": "road.arterial",
                         "elementType": "geometry.fill",
                         "stylers": [
                             {
                                 "lightness": "10"
                             },
                             {
                                 "gamma": "1"
                             }
                         ]
                     },
                     {
                         "featureType": "road.local",
                         "elementType": "geometry.fill",
                         "stylers": [
                             {
                                 "lightness": "10"
                             },
                             {
                                 "saturation": "-100"
                             }
                         ]
                     },
                     {
                         "featureType": "transit",
                         "elementType": "all",
                         "stylers": [
                             {
                                 "lightness": "-35"
                             }
                         ]
                     },
                     {
                         "featureType": "transit",
                         "elementType": "labels.text.stroke",
                         "stylers": [
                             {
                                 "visibility": "off"
                             }
                         ]
                     },
                     {
                         "featureType": "water",
                         "elementType": "all",
                         "stylers": [
                             {
                                 "saturation": "-97"
                             },
                             {
                                 "lightness": "-14"
                             }
                         ]
                     }
                     ]);
                             map.mapTypes.set('styled_map', styledMapType);
                             map.setMapTypeId('styled_map');
                         
                         var iconBase = '#data/images/icons/';
                         var icons = {
                             HD: {
                                 icon: iconBase + 'icon__map.png'
                             },
                         };
                     
                         var features = [
                             {
                                 position: new google.maps.LatLng(50.421121,30.5241317,17),
                                 type: 'HD'
                             },
                         ];
                     
                         // Create markers.
                         features.forEach(function (feature) {
                             marker = new google.maps.Marker({
                                 position: feature.position,
                                 icon: icons[feature.type].icon,
                                 map: map
                             });
                         });
                     
                         // $(window).bind('data-height-trigger', function(){
                         //     google.maps.event.trigger(map, "resize");
                         //     map.panTo(marker.getPosition());
                         // });
                     }
                     
                     head.ready(function() {
                         window.addEventListener('DOMContentLoaded', function() {
                             var map;
                             var marker;
                         });
                         $('#feedback_form input').blur(function() {
                             // console.log("blur");
                             if (!$.trim(this.value).length) {
                                 // $(this).parents('p').addClass('warning');
                                 $(this).removeClass("form-control--notempty");
                             } else {
                                 $(this).addClass("form-control--notempty");
                             }
                         });
                         // console.log($('.feedback-googlemap-form2__wrapper').outerHeight());
                         // $('input[name="feedback[phone]"]').mask("+38(099) 999-99-99");
                     });
                  </script>
                  <script async="" defer="" src="assets/js"></script>
               </div>
               <div class="mb50"></div>
               <script>
                  var correctCaptcha_3 = function(response) {
                      $("#response3").val(response);
                  };
                  head.ready(function() {
                      // $('.feedback-googlemap-form__form').addClass("dnone");
                      window.addEventListener('DOMContentLoaded', function() {
                          $('form#feedback_form67').validator().on('submit', function (e) {
                              if (e.isDefaultPrevented()) {
                                  // DataHeight.Set();
                                  //console.log('validation error');
                              } else {
                                  e.preventDefault();
                                  // DataHeight.Set();
                                  // var response = grecaptcha.getResponse();
                                  var response = $("#response3").val();
                  
                                  if (response.length == 0) {
                                      // reCaptcha not verified
                                      $('form#feedback_form67 .g-recaptcha').addClass('error');
                                  } else {
                                      // reCaptch verified
                                      $('form#feedback_form67 .g-recaptcha').removeClass('error');
                                      $.ajax({
                                          type: "POST",
                                          cache: false,
                                          url: "/tools/ajaxform/",
                                          data: $(this).serialize(),
                                          success: function (data) {
                                              $('#block_67').append(data);
                                              DataHeight.Set();
                                              $('.feedback-googlemap-form__form').removeClass("dnone");
                                              $('.feedback-googlemap-form2__inner').removeClass("feedback-googlemap-form2__inner--absolute");
                                              DataHeight.Set();
                                              console.log("submit 0");
                                              // if ($('.feedback-googlemap-form2__inner').visible(true)) {
                                                  // console.log("submit 1");
                                              // $('.feedback-googlemap-form__form').addClass("dnone");
                                              $('.feedback-googlemap-form__form').addClass("feedback-googlemap-form__form--success");
                                              $('.feedback-googlemap-form2__inner').addClass("feedback-googlemap-form2__inner--absolute");
                                              // }
                                          }
                                      });
                                  }
                              }
                          });
                  
                      });
                  });
               </script>
            </div>
            <div class="about-client__bg">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="h2__title">
                           <div class="h2__icon">
                              <span></span>
                              <span></span>
                              <span></span>
                           </div>
                           Принимаем оплату 
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div id="aboutCrypto" class="owl-carousel owl-theme owl-loaded">
                           <div class="owl-stage-outer">
                              <div class="owl-stage" style="transform: translate3d(0px, 0px, 0px); transition: all 0s ease 0s; width: 1228.34px;">
                                 <div class="owl-item active" style="width: 230.667px; margin-right: 15px;">
                                    <div class="about-client__item" data-height="client-item" data-height-sm="" data-height-xs="" style="height: 157px;">
                                       <div class="about-client__item__icon"><img src="assets/157_a.png" alt="Ethereum"></div>
                                    </div>
                                 </div>
                                 <div class="owl-item active" style="width: 230.667px; margin-right: 15px;">
                                    <div class="about-client__item" data-height="client-item" data-height-sm="" data-height-xs="" style="height: 157px;">
                                       <div class="about-client__item__icon"><img src="assets/156_a.png" alt="Tether"></div>
                                    </div>
                                 </div>
                                 <div class="owl-item active" style="width: 230.667px; margin-right: 15px;">
                                    <div class="about-client__item" data-height="client-item" data-height-sm="" data-height-xs="" style="height: 157px;">
                                       <div class="about-client__item__icon"><img src="assets/160_a.png" alt="Bitcoin"></div>
                                    </div>
                                 </div>
                                 <div class="owl-item active" style="width: 230.667px; margin-right: 15px;">
                                    <div class="about-client__item" data-height="client-item" data-height-sm="" data-height-xs="" style="height: 157px;">
                                       <div class="about-client__item__icon"><img src="assets/159_a.png" alt="Visa"></div>
                                    </div>
                                 </div>
                                 <div class="owl-item active" style="width: 230.667px; margin-right: 15px;">
                                    <div class="about-client__item" data-height="client-item" data-height-sm="" data-height-xs="" style="height: 157px;">
                                       <div class="about-client__item__icon"><img src="assets/161_a.png" alt="Mastercard"></div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="owl-controls">
                              <div class="owl-nav">
                                 <div class="owl-prev" style="display: none;">prev</div>
                                 <div class="owl-next" style="display: none;">next</div>
                              </div>
                              <div class="owl-dots" style="display: none;"></div>
                           </div>
                        </div>
                     </div>
                     <script>
                        head.ready(function() {
                            var owl = $("#aboutCrypto");
                            owl.owlCarousel({
                                items: 6,
                                loop: true,
                                margin: 15,
                                dots: false,
                                nav: false,
                                autoHeight: false,
                                // navText: ["<span class='lnr lnr-arrow-left'></span>", "<span class='lnr lnr-arrow-right'></span>"],
                                autoplay: true,
                                autoplayTimeout: 10000,
                                autoplaySpeed: 3000,
                                autoplayHoverPause: true,
                                // dotsContainer: '.owl-allwork__item__dots',
                                responsive : {
                                    0 : {
                                        items : 1,
                                    },
                                    300 : {
                                        items : 2,
                                    },
                                    768 : {
                                        items : 4,
                                    },
                                    992 : {
                                        items : 6,
                                    },
                                    1200 : {
                                        items : 6,
                                    }
                                }
                            });
                        });
                     </script>
                  </div>
               </div>
            </div>
            <div class="container">
            </div>
            <div class="html__bg">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="blockRawHtml">
                           <div class="lime-scrollbar mCustomScrollbar _mCS_1" style="max-height: 200px;">
                              <div id="mCSB_1" class="mCustomScrollBox mCS-light mCSB_vertical mCSB_inside" style="max-height: 200px;" tabindex="0">
                                 <div id="mCSB_1_container" class="mCSB_container" style="position:relative; top:0; left:0;" dir="ltr">
                                    <h1 style="font-size:15px;"><span style="color:#696969;">Юридическая фирма GRACERS</span></h1>
                                    <p><span style="color:#989898;"><span style="font-size:14px;">Юридическая фирма GRACERS - ведущая юридическая компания украинского рынка. Большой практический опыт и клиентоориентированность нашей команды экспертов, адвокатов, позволяет нам работать с задачами разного уровня сложности и предоставлять высококвалифицированную правовую помощь и консультации юриста.</span></span></p>
                                    <h2 style="font-size:15px;"><span style="color:#696969;">Услуги адвоката в Киеве</span></h2>
                                    <p><span style="color:#989898;"><span style="font-size:14px;">Сейчас право связано со всеми сферами жизни человека. Способные специалисты GRACERS предоставляют широкий спектр услуг адвоката с круглосуточной поддержкой клиентов в вопросах сопровождения исполнительного производства, семейного, налогового и уголовного права, судебных практик, IT, GR.<br>
                                       Опираясь на законодательную базу Украины и тщательно изучая нюансы каждого дела, мы практикуем комплексный гибкий подход к проблеме клиента, понимая деликатные особенности работы с различными отраслями права. Проанализировав информационную базу и обстоятельства дела, адвокаты GRACERS создадут и реализуют индивидуальную тактику юридического сопровождения.</span></span>
                                    </p>
                                    <h4 style="font-size:14px;"><span style="color:#696969;">Что делает нас уникальными?</span></h4>
                                    <p><span style="color:#989898;"><span style="font-size:14px;">Одним из приоритетных направлений работы адвокатской фирмы GRACERS является защита прав и интересов клиентов на разных этапах уголовного производства в отношении служебной деятельности. Мы предоставляем высококвалифицированную помощь адвоката по хозяйственным делам. Наши юристы и адвокаты предоставляют полный комплексное сопровождение, пользуясь большим положительным опытом в этой области права.<br>
                                       С целью защиты потерпевшей стороны, эксперты GRACERS готовы провести свое собственное расследование преступления: собрать доказательную базу, проверить существующие показания и показания свидетелей, истребовать и изучить все необходимые материалы чтобы в дальнейшем успешно возместить причиненные Вам убытки.</span></span>
                                    </p>
                                    <h3 style="font-size:14px;"><span style="color:#696969;">Нужен адвокат в Киеве?</span></h3>
                                    <p><span style="color:#989898;"><span style="font-size:14px;">Обращайтесь в юридическую фирма GRACERS. Наш коллектив это юристы и адвокаты со значительным опытом работы и соответствующим образованием, умеющие слаженно работать в команде. Вся информация о специалистах в свободном доступе находится на сайте для удобства наших клиентов.</span></span></p>
                                    <p><span style="color:#989898;"><span style="font-size:14px;">Юридическая компания GRACERS сосредоточивает свою деятельность на поиске прозрачных и эффективных решений, сохраняя конфиденциальность личности клиентов.<br>
                                       Наше профессиональное кредо - образцовые юридические услуги по исключительной цене!<br>
                                       Узнать компетентное мнение специалиста-адвоката можно обратившись за консультацией юриста или адвоката в городах Киев, Харьков, Одесса, Днепр.</span></span>
                                    </p>
                                 </div>
                                 <div id="mCSB_1_scrollbar_vertical" class="mCSB_scrollTools mCSB_1_scrollbar mCS-light mCSB_scrollTools_vertical" style="display: block;">
                                    <div class="mCSB_draggerContainer">
                                       <div id="mCSB_1_dragger_vertical" class="mCSB_dragger" style="position: absolute; min-height: 30px; display: block; height: 71px; max-height: 190px; top: 0px;">
                                          <div class="mCSB_dragger_bar" style="line-height: 30px;"></div>
                                       </div>
                                       <div class="mCSB_draggerRail"></div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="container">
            </div>
         </div>
      </div>
      <a id="return-to-top" style="display: none;">
         <svg class="svg-inline--fa fa-chevron-up fa-w-14" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="chevron-up" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg="">
            <path fill="currentColor" d="M240.971 130.524l194.343 194.343c9.373 9.373 9.373 24.569 0 33.941l-22.667 22.667c-9.357 9.357-24.522 9.375-33.901.04L224 227.495 69.255 381.516c-9.379 9.335-24.544 9.317-33.901-.04l-22.667-22.667c-9.373-9.373-9.373-24.569 0-33.941L207.03 130.525c9.372-9.373 24.568-9.373 33.941-.001z"></path>
         </svg>
         <!-- <i class="fas fa-chevron-up"></i> -->
      </a>
      <footer class="footer">
         <div class="footer__top">
            <div class="container">
               <div class="row">
                  <div class="col-lg-2 col-md-3 col-sm-4 col-xs-12">
                     <div class="footer__logo"><img src="assets/logo__footer-ru.png" alt="Услуги адвоката"></div>
                     <div class="footer__copy hidden-xs">2020-2022 © Киев. 
                        Все права захищены
                     </div>
                  </div>
                  <div class="col-lg-8 col-md-6 col-sm-5 col-xs-12">
                     <div class="container-fluid no__padding">
                        <div class="row">
                           <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 mb30">
                              <div class="container-fluid no__padding">
                                 <div class="row">
                                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                       <a class="footer__service__link__level1" href="#">-&nbsp;Уголовное право и процесс</a>
                                    </div>
                                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                       <a class="footer__service__link__level1" href="#">-&nbsp;Судебная практика</a>
                                    </div>
                                    <div class="clearfix visible-lg-block visible-md-block"></div>
                                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                       <a class="footer__service__link__level1" href="#">-&nbsp;Исполнительное производство</a>
                                    </div>
                                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                       <a class="footer__service__link__level1" href="#">-&nbsp;GR - взаимодействие с органами государственной власти</a>
                                    </div>
                                    <div class="clearfix visible-lg-block visible-md-block"></div>
                                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                       <a class="footer__service__link__level1" href="#">-&nbsp;Семейное право</a>
                                    </div>
                                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                       <a class="footer__service__link__level1" href="#">-&nbsp;Налоговое право</a>
                                    </div>
                                    <div class="clearfix visible-lg-block visible-md-block"></div>
                                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                       <a class="footer__service__link__level1" href="#">-&nbsp;Защита бизнеса</a>
                                    </div>
                                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                       <a class="footer__service__link__level1" href="#">-&nbsp;Поддержка IT-компаний</a>
                                    </div>
                                    <div class="clearfix visible-lg-block visible-md-block"></div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 mb30">
                              <div>
                                 <a class="footer__catalog__link__level1" href="#">О нас</a>
                              </div>
                              <div>
                                 <a class="footer__catalog__link__level1" href="#">Команда</a>
                              </div>
                              <div>
                                 <a class="footer__catalog__link__level1" href="#">Пресс-центр</a>
                              </div>
                              <div>
                                 <a class="footer__catalog__link__level1" href="#">Контакты</a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">
                     <div class="footer__copy visible-xs">2020-2022 © Киев. 
                        Все права захищены
                     </div>
                     <div class="general"><a title="Создание сайтов  в Киеве" href="https://www.limenet.kiev.ua/" target="_blank">Создание сайта <span class="devel__logo"></span></a></div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <!-- Modal -->
      <div class="modal fade" id="ajaxModal" role="dialog">
         <div class="modal-dialog" role="document">
            <div class="modal-content">
               <div class="modal-header">
                  <div class="pop-up__close-btn" data-dismiss="modal" aria-label="Close"><span class="lnr lnr-cross"></span></div>
                  <h4 class="pop-up__title" id="myModalLabel">
                     <!-- TITLE -->
                  </h4>
               </div>
               <div class="modal-body">
                  <!-- BODY -->
               </div>
               <!--div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                  <button type="button" class="btn btn-primary">Save changes</button>
                  </div-->
            </div>
         </div>
      </div>
      <!-- Modal -->
      <div class="modal fade" id="ajaxModal2" role="dialog">
         <div class="modal-dialog" role="document">
            <div class="modal-content">
               <div class="modal-header">
                  <div class="pop-up__close-btn" data-dismiss="modal" aria-label="Close"><span class="lnr lnr-cross"></span></div>
                  <h4 class="pop-up__title" id="myModalLabel">
                     <!-- TITLE -->
                  </h4>
               </div>
               <div class="modal-body">
                  <!-- BODY -->
               </div>
               <!--div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                  <button type="button" class="btn btn-primary">Save changes</button>
                  </div-->
            </div>
         </div>
      </div>
   </body>
</html>