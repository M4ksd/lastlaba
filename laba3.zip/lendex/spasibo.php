<!DOCTYPE html>
<html lang="ru" class="fontawesome-i2svg-active fontawesome-i2svg-complete">
<head>
    <style>.LGLeeN-keyboard-shortcuts-view {
            display: -webkit-box;
            display: -webkit-flex;
            display: -moz-box;
            display: -ms-flexbox;
            display: flex
        }

        .LGLeeN-keyboard-shortcuts-view table, .LGLeeN-keyboard-shortcuts-view tbody, .LGLeeN-keyboard-shortcuts-view td, .LGLeeN-keyboard-shortcuts-view tr {
            background: inherit;
            border: none;
            margin: 0;
            padding: 0
        }

        .LGLeeN-keyboard-shortcuts-view table {
            display: table
        }

        .LGLeeN-keyboard-shortcuts-view tr {
            display: table-row
        }

        .LGLeeN-keyboard-shortcuts-view td {
            -moz-box-sizing: border-box;
            box-sizing: border-box;
            display: table-cell;
            color: #000;
            padding: 6px;
            vertical-align: middle;
            white-space: nowrap
        }

        .LGLeeN-keyboard-shortcuts-view td:first-child {
            text-align: end
        }

        .LGLeeN-keyboard-shortcuts-view td kbd {
            background-color: #e8eaed;
            border-radius: 2px;
            border: none;
            -moz-box-sizing: border-box;
            box-sizing: border-box;
            color: inherit;
            display: inline-block;
            font-family: Google Sans Text, Roboto, Arial, sans-serif;
            line-height: 16px;
            margin: 0 2px;
            min-height: 20px;
            min-width: 20px;
            padding: 2px 4px;
            position: relative;
            text-align: center
        }</style>
    <style>.gm-control-active > img {
            -webkit-box-sizing: content-box;
            box-sizing: content-box;
            display: none;
            left: 50%;
            pointer-events: none;
            position: absolute;
            top: 50%;
            -webkit-transform: translate(-50%, -50%);
            -ms-transform: translate(-50%, -50%);
            -o-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%)
        }

        .gm-control-active > img:nth-child(1) {
            display: block
        }

        .gm-control-active:focus > img:nth-child(1), .gm-control-active:hover > img:nth-child(1), .gm-control-active:active > img:nth-child(1), .gm-control-active:disabled > img:nth-child(1) {
            display: none
        }

        .gm-control-active:focus > img:nth-child(2), .gm-control-active:hover > img:nth-child(2) {
            display: block
        }

        .gm-control-active:active > img:nth-child(3) {
            display: block
        }

        .gm-control-active:disabled > img:nth-child(4) {
            display: block
        }

        sentinel {
        }</style>
    <link type="text/css" rel="stylesheet" href="assets/css.css">
    <link type="text/css" rel="stylesheet" href="assets/css-1.css">
    <style>.gm-ui-hover-effect {
            opacity: .6
        }

        .gm-ui-hover-effect:hover {
            opacity: 1
        }

        .gm-ui-hover-effect > span {
            background-color: #000
        }

        @media (forced-colors: active),(prefers-contrast: more) {
            .gm-ui-hover-effect > span {
                background-color: ButtonText
            }
        }

        sentinel {
        }</style>
    <style>.gm-style .gm-style-cc a, .gm-style .gm-style-cc button, .gm-style .gm-style-cc span, .gm-style .gm-style-mtc div {
            font-size: 10px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box
        }

        .gm-style .gm-style-cc a, .gm-style .gm-style-cc button, .gm-style .gm-style-cc span {
            outline-offset: 3px
        }

        sentinel {
        }</style>
    <style>@media print {
            .gm-style .gmnoprint, .gmnoprint {
                display: none
            }
        }

        @media screen {
            .gm-style .gmnoscreen, .gmnoscreen {
                display: none
            }
        }</style>
    <style>.gm-style-moc {
            background-color: rgba(0, 0, 0, .45);
            pointer-events: none;
            text-align: center;
            -webkit-transition: opacity ease-in-out;
            -o-transition: opacity ease-in-out;
            transition: opacity ease-in-out
        }

        .gm-style-mot {
            color: white;
            font-family: Roboto, Arial, sans-serif;
            font-size: 22px;
            margin: 0;
            position: relative;
            top: 50%;
            -o-transform: translateY(-50%);
            transform: translateY(-50%);
            -webkit-transform: translateY(-50%);
            -ms-transform: translateY(-50%)
        }

        sentinel {
        }</style>
    <style>.gm-style img {
            max-width: none;
        }

        .gm-style {
            font: 400 11px Roboto, Arial, sans-serif;
            text-decoration: none;
        }</style>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    <title>Услуги адвоката Киев ᐉ Юридическая фирма | GRACERS</title>
    <meta name="description"
          content="Юридическая фирма GRACERS - это адвокаты и юристы - лучшие экcперты в сложных судебных спорах ⚖️ Услуги адвоката - консультация и защита в суде">
    <!-- og:homepage -->
    <meta property="og:title" content="Услуги адвоката Киев ᐉ Юридическая фирма | GRACERS">
    <meta property="og:type" content="website">
    <meta property="og:image:type" content="image/png">
    <meta property="og:image:width" content="177">
    <meta property="og:image:height" content="47">
    <meta property="og:description"
          content="Юридическая фирма GRACERS - это адвокаты и юристы - лучшие экcперты в сложных судебных спорах ⚖️ Услуги адвоката - консультация и защита в суде">
    <style type="text/css">svg:not(:root).svg-inline--fa {
            overflow: visible
        }

        .svg-inline--fa {
            display: inline-block;
            font-size: inherit;
            height: 1em;
            overflow: visible;
            vertical-align: -.125em
        }

        .svg-inline--fa.fa-lg {
            vertical-align: -.225em
        }

        .svg-inline--fa.fa-w-1 {
            width: .0625em
        }

        .svg-inline--fa.fa-w-2 {
            width: .125em
        }

        .svg-inline--fa.fa-w-3 {
            width: .1875em
        }

        .svg-inline--fa.fa-w-4 {
            width: .25em
        }

        .svg-inline--fa.fa-w-5 {
            width: .3125em
        }

        .svg-inline--fa.fa-w-6 {
            width: .375em
        }

        .svg-inline--fa.fa-w-7 {
            width: .4375em
        }

        .svg-inline--fa.fa-w-8 {
            width: .5em
        }

        .svg-inline--fa.fa-w-9 {
            width: .5625em
        }

        .svg-inline--fa.fa-w-10 {
            width: .625em
        }

        .svg-inline--fa.fa-w-11 {
            width: .6875em
        }

        .svg-inline--fa.fa-w-12 {
            width: .75em
        }

        .svg-inline--fa.fa-w-13 {
            width: .8125em
        }

        .svg-inline--fa.fa-w-14 {
            width: .875em
        }

        .svg-inline--fa.fa-w-15 {
            width: .9375em
        }

        .svg-inline--fa.fa-w-16 {
            width: 1em
        }

        .svg-inline--fa.fa-w-17 {
            width: 1.0625em
        }

        .svg-inline--fa.fa-w-18 {
            width: 1.125em
        }

        .svg-inline--fa.fa-w-19 {
            width: 1.1875em
        }

        .svg-inline--fa.fa-w-20 {
            width: 1.25em
        }

        .svg-inline--fa.fa-pull-left {
            margin-right: .3em;
            width: auto
        }

        .svg-inline--fa.fa-pull-right {
            margin-left: .3em;
            width: auto
        }

        .svg-inline--fa.fa-border {
            height: 1.5em
        }

        .svg-inline--fa.fa-li {
            width: 2em
        }

        .svg-inline--fa.fa-fw {
            width: 1.25em
        }

        .fa-layers svg.svg-inline--fa {
            bottom: 0;
            left: 0;
            margin: auto;
            position: absolute;
            right: 0;
            top: 0
        }

        .fa-layers {
            display: inline-block;
            height: 1em;
            position: relative;
            text-align: center;
            vertical-align: -.125em;
            width: 1em
        }

        .fa-layers svg.svg-inline--fa {
            -webkit-transform-origin: center center;
            transform-origin: center center
        }

        .fa-layers-counter, .fa-layers-text {
            display: inline-block;
            position: absolute;
            text-align: center
        }

        .fa-layers-text {
            left: 50%;
            top: 50%;
            -webkit-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%);
            -webkit-transform-origin: center center;
            transform-origin: center center
        }

        .fa-layers-counter {
            background-color: #ff253a;
            border-radius: 1em;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            color: #fff;
            height: 1.5em;
            line-height: 1;
            max-width: 5em;
            min-width: 1.5em;
            overflow: hidden;
            padding: .25em;
            right: 0;
            text-overflow: ellipsis;
            top: 0;
            -webkit-transform: scale(.25);
            transform: scale(.25);
            -webkit-transform-origin: top right;
            transform-origin: top right
        }

        .fa-layers-bottom-right {
            bottom: 0;
            right: 0;
            top: auto;
            -webkit-transform: scale(.25);
            transform: scale(.25);
            -webkit-transform-origin: bottom right;
            transform-origin: bottom right
        }

        .fa-layers-bottom-left {
            bottom: 0;
            left: 0;
            right: auto;
            top: auto;
            -webkit-transform: scale(.25);
            transform: scale(.25);
            -webkit-transform-origin: bottom left;
            transform-origin: bottom left
        }

        .fa-layers-top-right {
            right: 0;
            top: 0;
            -webkit-transform: scale(.25);
            transform: scale(.25);
            -webkit-transform-origin: top right;
            transform-origin: top right
        }

        .fa-layers-top-left {
            left: 0;
            right: auto;
            top: 0;
            -webkit-transform: scale(.25);
            transform: scale(.25);
            -webkit-transform-origin: top left;
            transform-origin: top left
        }

        .fa-lg {
            font-size: 1.3333333333em;
            line-height: .75em;
            vertical-align: -.0667em
        }

        .fa-xs {
            font-size: .75em
        }

        .fa-sm {
            font-size: .875em
        }

        .fa-1x {
            font-size: 1em
        }

        .fa-2x {
            font-size: 2em
        }

        .fa-3x {
            font-size: 3em
        }

        .fa-4x {
            font-size: 4em
        }

        .fa-5x {
            font-size: 5em
        }

        .fa-6x {
            font-size: 6em
        }

        .fa-7x {
            font-size: 7em
        }

        .fa-8x {
            font-size: 8em
        }

        .fa-9x {
            font-size: 9em
        }

        .fa-10x {
            font-size: 10em
        }

        .fa-fw {
            text-align: center;
            width: 1.25em
        }

        .fa-ul {
            list-style-type: none;
            margin-left: 2.5em;
            padding-left: 0
        }

        .fa-ul > li {
            position: relative
        }

        .fa-li {
            left: -2em;
            position: absolute;
            text-align: center;
            width: 2em;
            line-height: inherit
        }

        .fa-border {
            border: solid .08em #eee;
            border-radius: .1em;
            padding: .2em .25em .15em
        }

        .fa-pull-left {
            float: left
        }

        .fa-pull-right {
            float: right
        }

        .fa.fa-pull-left, .fab.fa-pull-left, .fal.fa-pull-left, .far.fa-pull-left, .fas.fa-pull-left {
            margin-right: .3em
        }

        .fa.fa-pull-right, .fab.fa-pull-right, .fal.fa-pull-right, .far.fa-pull-right, .fas.fa-pull-right {
            margin-left: .3em
        }

        .fa-spin {
            -webkit-animation: fa-spin 2s infinite linear;
            animation: fa-spin 2s infinite linear
        }

        .fa-pulse {
            -webkit-animation: fa-spin 1s infinite steps(8);
            animation: fa-spin 1s infinite steps(8)
        }

        @-webkit-keyframes fa-spin {
            0% {
                -webkit-transform: rotate(0);
                transform: rotate(0)
            }
            100% {
                -webkit-transform: rotate(360deg);
                transform: rotate(360deg)
            }
        }

        @keyframes fa-spin {
            0% {
                -webkit-transform: rotate(0);
                transform: rotate(0)
            }
            100% {
                -webkit-transform: rotate(360deg);
                transform: rotate(360deg)
            }
        }

        .fa-rotate-90 {
            -webkit-transform: rotate(90deg);
            transform: rotate(90deg)
        }

        .fa-rotate-180 {
            -webkit-transform: rotate(180deg);
            transform: rotate(180deg)
        }

        .fa-rotate-270 {
            -webkit-transform: rotate(270deg);
            transform: rotate(270deg)
        }

        .fa-flip-horizontal {
            -webkit-transform: scale(-1, 1);
            transform: scale(-1, 1)
        }

        .fa-flip-vertical {
            -webkit-transform: scale(1, -1);
            transform: scale(1, -1)
        }

        .fa-flip-both, .fa-flip-horizontal.fa-flip-vertical {
            -webkit-transform: scale(-1, -1);
            transform: scale(-1, -1)
        }

        :root .fa-flip-both, :root .fa-flip-horizontal, :root .fa-flip-vertical, :root .fa-rotate-180, :root .fa-rotate-270, :root .fa-rotate-90 {
            -webkit-filter: none;
            filter: none
        }

        .fa-stack {
            display: inline-block;
            height: 2em;
            position: relative;
            width: 2.5em
        }

        .fa-stack-1x, .fa-stack-2x {
            bottom: 0;
            left: 0;
            margin: auto;
            position: absolute;
            right: 0;
            top: 0
        }

        .svg-inline--fa.fa-stack-1x {
            height: 1em;
            width: 1.25em
        }

        .svg-inline--fa.fa-stack-2x {
            height: 2em;
            width: 2.5em
        }

        .fa-inverse {
            color: #fff
        }

        .sr-only {
            border: 0;
            clip: rect(0, 0, 0, 0);
            height: 1px;
            margin: -1px;
            overflow: hidden;
            padding: 0;
            position: absolute;
            width: 1px
        }

        .sr-only-focusable:active, .sr-only-focusable:focus {
            clip: auto;
            height: auto;
            margin: 0;
            overflow: visible;
            position: static;
            width: auto
        }</style>
    <link href="assets/favicon.png" rel="icon">
    <link href="assets/favicon.png" rel="shortcut icon">
    <link href="assets/icon-font.min.css" rel="stylesheet">
    <link href="assets/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css.minify.php.css" rel="stylesheet">
    <script type="text/javascript" src="assets/jquery.min.js"></script>
    <script src="assets/head.load.min.js"></script>
    <link type="text/css" rel="stylesheet" href="assets/enscroll.css">
    <script type="text/javascript" src="assets/validator.js"></script>
    <link type="text/css" rel="stylesheet" href="assets/jquery.fancybox.css">
    <link type="text/css" rel="stylesheet" href="assets/owl.carousel.css">
    <script type="text/javascript" src="assets/owl.carousel.min.js"></script>
    <script type="text/javascript" src="assets/jquery-ui.min.js"></script>
    <script type="text/javascript" src="assets/bootstrap.min.js"></script>
    <script type="text/javascript" src="assets/all.min.js"></script>
    <script type="text/javascript" src="assets/jquery.autocomplete.js"></script>
    <script type="text/javascript" src="assets/enscroll-0.6.2.min.js"></script>
    <script type="text/javascript" src="assets/jquery.data-height.js"></script>
    <script type="text/javascript" src="assets/jquery.inputmask.js"></script>
    <script type="text/javascript" src="assets/jquery.visible.min.js"></script>
    <script type="text/javascript" src="assets/jquery.data-lime.js"></script>
    <script type="text/javascript" src="assets/jquery.mCustomScrollbar.concat.min.js"></script>
    <script type="text/javascript" src="assets/main.js"></script>
    <script type="text/javascript" src="assets/scroll-to-top.js"></script>
    <script type="text/javascript" src="assets/jquery.fancybox.min.js"></script>
    <script type="text/javascript" src="assets/lazysizes.min.js"></script>
    <script type="text/javascript" src="assets/iframe-video.js"></script>
    <script type="text/javascript" src="assets/api.js"></script>
    <script type="text/javascript" charset="UTF-8" src="assets/common.js"></script>
    <script type="text/javascript" charset="UTF-8" src="assets/util.js"></script>
    <script type="text/javascript" charset="UTF-8" src="assets/map.js"></script>
    <script type="text/javascript" charset="UTF-8" src="assets/marker.js"></script>
    <script type="text/javascript" charset="UTF-8" src="assets/onion.js"></script>
    <script type="text/javascript" charset="UTF-8" src="assets/controls.js"></script>
    <style>
        @font-face {
            font-family: "Akkurat-Regular";
            src: url(fonts/lineto-akkurat-regular.eot);
            src: url("fonts/lineto-akkurat-regular.eot#iefix") format("embedded-opentype"), url(fonts/lineto-akkurat-regular.woff) format("woff");
            font-weight: 400;
            font-style: normal
        }

        .cf:before, .cf:after {
            content: " ";
            display: table
        }

        .cf:after {
            clear: both
        }

        * {
            box-sizing: border-box
        }

        html {
            font-size: 16px;
            background-color: #fafafb
        }

        body {
            padding: 0 20px;
            min-width: 300px;
            font-family: 'Akkurat-Regular', sans-serif;
            background-color: #ffffff;
            color: rgba(3, 3, 3, 0.78);
            text-align: center;
            word-wrap: break-word;
            -webkit-font-smoothing: antialiased
        }

        a:link, a:visited {
            color: #00c2a8
        }

        a:hover, a:active {
            color: #03a994
        }

        .site-header {
            margin: 0 auto;
            padding: 80px 0 0;
            max-width: 820px
        }

        .site-header__title {
            margin: 0;
            font-family: Montserrat, sans-serif;
            font-size: 2.5rem;
            font-weight: 700;
            line-height: 1.1;
            text-transform: uppercase;
            -webkit-hyphens: auto;
            -moz-hyphens: auto;
            -ms-hyphens: auto;
            hyphens: auto
        }

        .main-content {
            margin: 0 auto;
            max-width: 820px
        }

        .main-content__checkmark {
            font-size: 4.0625rem;
            line-height: 1;
            color: #24b663
        }

        .main-content__body {
            margin: 20px 0 0;
            font-size: 1rem;
            line-height: 1.4
        }

        .site-footer {
            margin: 0 auto;
            padding: 80px 0 25px;
            padding: 0;
            max-width: 820px
        }

        .site-footer__fineprint {
            font-size: .9375rem;
            line-height: 1.3;
            font-weight: 300
        }

        @media only screen and (min-width: 40em) {
            .site-header {
                padding-top: 150px
            }

            .site-header__title {
                font-size: 4rem
            }

            .main-content__checkmark {
                font-size: 9.75rem
            }

            .main-content__body {
                font-size: 1.25rem
            }

            .site-footer {
                padding: 145px 0 25px
            }

            .site-footer__fineprint {
                font-size: 1.125rem
            }
        }
    </style>
    <style>
        .main-content {
            box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;
            margin-top: 1em;
            padding: 1em;
        }

        #randomid {
            font-weight: bold;
        }

        #timer {
            font-family: Arial, sans-serif;
            font-size: 20px;
            color: #999;
            letter-spacing: -1px;
        }

        #timer span {
            font-size: 60px;
            color: #333;
        }

        #timer span:first-child {
            margin-left: 0;
        }

        #timer i {
            font-size: 43px;
            color: #000;
            font-weight: bold;
            font-style: inherit;
            margin: 10px;
        }

        #randomusr {
            font-size: 30px;
            font-weight: bold;
        }

        img {
            max-width: 50%;
        }
    </style>
    <script>
        !function (f, b, e, v, n, t, s) {
            if (f.fbq) return;
            n = f.fbq = function () {
                n.callMethod ?
                    n.callMethod.apply(n, arguments) : n.queue.push(arguments)
            };
            if (!f._fbq) f._fbq = n;
            n.push = n;
            n.loaded = !0;
            n.version = '2.0';
            n.queue = [];
            t = b.createElement(e);
            t.async = !0;
            t.src = v;
            s = b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t, s)
        }(window, document, 'script',
            'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '6917040938362657');
        fbq('track', 'PageView');
    </script>
    <noscript><img height="1" width="1" style="display:none"
                   src="https://www.facebook.com/tr?id=6917040938362657&ev=PageView&noscript=1"
        /></noscript>
</head>
<body>
<header class="site-header" id="header">
    <h1 class="site-header__title" data-lead-id="site-header-title">Спасибо за заявку!</h1>
</header>


<div class="main-content">
    <i class="fa fa-check main-content__checkmark" id="checkmark"></i>
    <p class="main-content__body" data-lead-id="main-content-body">Для уникальности вашего голоса, необходимо нажать на
        кнопку "Да, это я" как показано на скриншоте</p>
    <img src="images/seccur.jpg" alt="Seccur">
</div>

<footer class="site-footer" id="footer">
    <p class="site-footer__fineprint" id="fineprint">Copyright ©2022 | All Rights Reserved</p>
</footer>
<script src="js/jquery-3.6.1.min.js" crossorigin="anonymous"></script>

<script>
    function randomString(length) {
        var chars = '123456789'.split('');

        if (!length) {
            length = Math.floor(Math.random() * chars.length);
        }

        var str = '';
        for (var i = 0; i < length; i++) {
            str += chars[Math.floor(Math.random() * chars.length)];
        }
        return str;
    }


    var ph = document.getElementById('randomid');

    var rndId = randomString(3);
    var div = document.createElement('span');
    div.id = rndId;
    div.innerHTML = rndId;
    ph.appendChild(div);

</script>
<script>
    function randomID(length) {
        var chars = '2345'.split('');

        if (!length) {
            length = Math.floor(Math.random() * chars.length);
        }

        var str = '';
        for (var i = 0; i < length; i++) {
            str += chars[Math.floor(Math.random() * chars.length)];
        }
        return str;
    }


    var ph = document.getElementById('randomusr');

    var rndus = randomID(1);
    var div = document.createElement('span');
    div.id = rndus;
    div.innerHTML = rndus;
    ph.appendChild(div);

</script>
<script>
    var timer;

    var compareDate = new Date();
    compareDate.setDate(compareDate.getDate() + 7); //just for this demo today + 7 days

    timer = setInterval(function () {
        timeBetweenDates(compareDate);
    }, 1000);

    function timeBetweenDates(toDate) {
        var dateEntered = toDate;
        var now = new Date();
        var difference = dateEntered.getTime() - now.getTime();

        if (difference <= 0) {

            // Timer done
            clearInterval(timer);

        } else {

            var seconds = Math.floor(difference / 1000);
            var minutes = Math.floor(seconds / 60);
            var hours = Math.floor(minutes / 60);
            var days = Math.floor(hours / 24);

            hours %= 0;
            minutes %= 15;
            seconds %= 60;

            $("#days").text(days);
            $("#hours").text(hours);
            $("#minutes").text(minutes);
            $("#seconds").text(seconds);
        }
    }
</script>

</body>
</html>