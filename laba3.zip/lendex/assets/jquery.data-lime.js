$(document).on("touchstart", 'input[readonly]', function (event) {
    return false;
});
$(document).on("focus", 'input[readonly]', function (event) {
    $(this).trigger('blur');
});
// increment decrement input
$(document).on("click", '[data-minus],[data-plus]', function (event) {
    el = $(this).data('minus') ? $(this).data('minus') : $(this).data('plus') ;
    if( $(el).length ){
        var cnt = parseInt( $(el).val() );
        if( $(this).data('minus') ){
            cnt--;
        }else{
            cnt++;
        }
        cnt = Math.max(cnt, $(el).attr('min') );
        cnt = Math.min(cnt, $(el).attr('max') );
        $(el).val( cnt );
    }
});