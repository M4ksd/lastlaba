/**
 * data-height="уникальный ИД блоков которые надо выровнять по высоте"
 * data-height-max этот элемент лидирующий, вся семья по его высоте
 * sm xs по умолчанию игнорирются
 * data-height-sm если нужно и в этом размере
 * data-height-xs если нужно и в этом размере
 */
$(window).on("load resize", function(e){
    DataHeight.Set();
});

$(window).bind('data-height-change', function(){
    //console.log('data-height-change');
    //DataHeight.Set();
});

DataHeight = {
    Set: function(){
        $('[data-height]').css('height', 'auto');
        // выравнивание блоков по высоте data-height="group-name"
        var dataHeightArr = new Array();
        $('[data-height]').each(function(){
            if( dataHeightArr.indexOf($(this).data('height')) == -1 ){
                dataHeightArr.push( $(this).data('height') );
            }
        });
        $.each(dataHeightArr, function(i,el){
            allowSM = $('[data-height="'+el+'"][data-height-sm]').length ? true : false;
            allowXS = $('[data-height="'+el+'"][data-height-xs]').length ? true : false;
            if( $(window).width() >= 768 && $(window).width() <= 991 && !allowSM ){
            }else if( $(window).width() <= 767 && !allowXS ){
            }else{
                max = 0;
                if( $('[data-height="'+el+'"][data-height-max]').length ){
                    $('[data-height="'+el+'"][data-height-max]').each(function(){
                        max = Math.max( max, Math.ceil($(this).outerHeight(false)) );
                    });
                }else{
                    $('[data-height="'+el+'"]').each(function(){
                        max = Math.max( max, Math.ceil($(this).outerHeight(false)) );
                    });
                }
                $('[data-height="'+el+'"]').css('height', max);
            }
        });
        $(window).trigger('data-height-trigger');
    }
}
