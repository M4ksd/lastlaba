var is_touch_device = 'ontouchstart' in window;
if (is_touch_device) {
    $('body').addClass('touch-device');
}

/* scrollbar */
$('.lime-scrollbar').mCustomScrollbar();

// function onSuccess(googleUser) {
//     console.log('Logged in as: ' + googleUser.getBasicProfile().getName());
// }
// function onFailure(error) {
//     console.log(error);
// }
// function renderButton() {
//     gapi.signin2.render('ult-signin2', {
//         // 'scope': 'profile email',
//         'width': 14,
//         'height': 16,
//         'longtitle': true,
//         'theme': 'dark',
//         'onsuccess': onSuccess,
//         'onfailure': onFailure
//     });
// }

// // close || open. filter
// $('.catalog-tovars__podbor__specif>.catalog-tovars__podbor__specif__header').on('click', function () {
//     $(this).parent().toggleClass('closed');
// });

// // profile order history
// $('.profile__content__orders__order').click(function () {
//     $(this).next().slideToggle(400);
// });

// // autocomplete
// $('#words').autocomplete({
//     serviceUrl: '/tools/search/',
//     appendTo: '#search-input-result'
// });

$(window).bind('load resize', function () {
    // $('input[name="feedback[phone]"]').mask("+38 099 999 99 99");
    $('input[name="feedback[phone]"]').inputmask("+38 099 999 99 99");

    $('.feedback-googlemap-form__form').removeClass("dnone");
    $('.feedback-googlemap-form2__inner').removeClass("feedback-googlemap-form2__inner--absolute");
    DataHeight.Set();
    // console.log("load resize 0");
    if ($('.feedback-googlemap-form2__inner').visible(true)) {
        $('.feedback-googlemap-form__form').addClass("dnone");
        $('.feedback-googlemap-form2__inner').addClass("feedback-googlemap-form2__inner--absolute");
        // DataHeight.Set();
    } else {
        // console.log("load resize 2");
        // DataHeight.Set();
        // The element is NOT visible, do something else
    }
});

// datepicker
if ($(".datepicker").length) {
    $(".datepicker").datetimepicker({
        format: 'YYYY-MM-DD',
        locale: 'ru',
    });
}
// datepicker
if ($(".hourpicker").length) {
    $(".hourpicker").datetimepicker({
        format: 'HH:00',
        locale: 'ru',
    });
}

// // subscribe
// $('form#subscribe_form').validator().on('submit', function (e) {
//     if (e.isDefaultPrevented()) {
//         //console.log('validation error');
//     } else {
//         e.preventDefault();
//         //console.log('validation OK');
//         AjaxForm.Subscribe($('#bottom_subscribe').val());
//     }
// });

// ajax form submit on keypress 13 (enter)
$(document).on("keypress", '.modal form input', function (event) {
    if (event.which == 13) {
        event.preventDefault();
        $(this).closest('form').submit();
    }
});

$(document).on('ready', function() {
    // $('input[name="feedback[phone]"]').inputmask("+38 099 999 99 99");
});

$(window).on('resize scroll', function() {
        // $('.feedback-googlemap-form2__inner').removeClass("feedback-googlemap-form2__inner--absolute");
        // DataHeight.Set();
    // console.log("load resize 0");
    if ($('.feedback-googlemap-form2__inner').visible(true)) {
        // console.log("load resize 1");
        $('.feedback-googlemap-form__form:not(.feedback-googlemap-form__form--active)').addClass("dnone feedback-googlemap-form__form--active");
        $('.feedback-googlemap-form2__inner').addClass("feedback-googlemap-form2__inner--absolute");
        // DataHeight.Set();
    } else {
        // console.log("load resize 2");
        // DataHeight.Set();
        // The element is NOT visible, do something else
    }
});
// scroll to top
$('.scroll-to-top').click(function () {
    $('html,body').animate({scrollTop: 0}, 350);
});

$(function () {
    if (window.matchMedia('(max-width:991px)').matches) {
        $( ".dropdown-submenu" ).click(function(event) {
            // alert('bla');
            // stop bootstrap.js to hide the parents
            event.stopPropagation();
            // hide the open children
            // $( this ).find(".dropdown-submenu").removeClass('open');
            // // add 'open' class to all parents with class 'dropdown-submenu'
            // $( this ).parents(".dropdown-submenu").addClass('open');
            // this is also open (or was)
            $( this ).toggleClass('open');
        });
    }
    // fancybox
    if ($("[rel='lightbox'], .fancybox").length) {
        $("[rel='lightbox'], .fancybox").fancybox();
    }
    // // show|hide button
    // $('#header__search-button').click(function () {
    //     $(this).toggleClass('search');
    //     $(this).find('.fa').toggleClass('hidden');
    //     $('.header__logoicon__logo-container').toggleClass('search');
    // });
    // // rating
    // $(".rating-item").rating();
    // // menu
    // var topMenu = $('#topMenu-container');
    // var topPosition = topMenu.offset().top;
    // $(window).scroll(function () {
    //     if ($(window).scrollTop() > topPosition + 10) {
    //         topMenu.addClass("topMenu-float");
    //     } else {
    //         topMenu.removeClass("topMenu-float");
    //     }
    // });
    // /* tabs owl-carousel */
    // $('.catalog-anons-tabs__link').click(function () {
    //     $(this).parent().find('.catalog-anons-tabs__link').removeClass('active');
    //     $(this).addClass('active');
    //     gId = $(this).data('galleryId');
    //     $('.owl-catanons').removeClass('active');
    //     $('#' + gId).addClass('active');
    // });
    // // onetovar
    // if ($('.one-tovar').length) {
    //     // one-tovar scroll to comments
    //     $('.one-tovar').on('click', '#scroll-comments', function () {
    //         var winIsSmall = $(window).width() < 768;
    //         var sTo = ($('#messages').offset().top -(winIsSmall ? 0 : 1) * $('#topMenu-container').outerHeight());
    //         console.log($('#messages').offset().top);
    //         console.log($('#topMenu-container').outerHeight());
    //         console.log(sTo);
    //         $('body,html').animate({scrollTop: sTo}, 300);
    //     });
    //     $('.one-tovar').on('click', '#scroll-comments-new', function (e) {
    //
    //         $('.nav-tabs#messages a[href="#messages-add"]').trigger('click');
    //     });
    //     $('.one-tovar [data-fancybox]').fancybox({
    //         loop: true,
    //         thumbs: {
    //             autoStart: true, // Display thumbnails on opening
    //             hideOnClose: true   // Hide thumbnail grid when closing animation starts
    //         }
    //     });
    //     if ($(".owl-onetovar-onePhoto").length) {
    //         var owl1 = $(".owl-onetovar-onePhoto");
    //         slideCnt1 = owl1.find('>div').length;
    //         owl1.owlCarousel({
    //             items: 1,
    //             margin: 0,
    //             dots: false,
    //             nav: false,
    //             loop: false
    //         });
    //         $('.one-tovar__main__gallery__thumbs__thumb').click(function () {
    //             $('.one-tovar__main__gallery__thumbs__thumb').removeClass('active');
    //             $(this).addClass('active');
    //             var number = $(this).index();
    //             owl1.trigger("to.owl.carousel", [number, 300, true]);
    //         });
    //     }
    //     if ($(".owl-onetovar-smallPhoto").length) {
    //         var owl2 = $(".owl-onetovar-smallPhoto");
    //         slideCnt2 = owl2.find('>div').length;
    //         owl2.owlCarousel({
    //             margin: 20,
    //             dots: false,
    //             nav: true,
    //             navText: ["<span class='lnr lnr-chevron-left'></span>", "<span class='lnr lnr-chevron-right'></span>"],
    //             loop: false,
    //             responsive: {
    //                 0: {
    //                     items: 1,
    //                     nav: (slideCnt2 > 1)
    //                 },
    //                 600: {
    //                     items: 2,
    //                     nav: (slideCnt2 > 2)
    //                 },
    //                 768: {
    //                     items: 3,
    //                     nav: (slideCnt2 > 3)
    //                 },
    //                 1200: {
    //                     items: 4,
    //                     nav: (slideCnt2 > 4)
    //                 },
    //                 1500: {
    //                     items: 5,
    //                     nav: (slideCnt2 > 5)
    //                 }
    //             },
    //             onInitialized: function () {
    //                 owl2.find(".owl-item")
    //                         .eq(0)
    //                         .addClass('current');
    //             }
    //         });
    //     }
    // if (slideCnt1 > 1 && slideCnt2 > 1) {
    //     owl1.on('changed.owl.carousel', function (event) {
    //         var number = event.item.index;
    //         //var tempFix = number - (event.relatedTarget.clones().length / 2);
    //         //if(tempFix > 0) {number = tempFix - 1;}
    //         console.log('owl1index = ' + number);
    //         owl2.trigger("to.owl.carousel", [number, 300, true]);
    //         owl2.find(".owl-item")
    //                 .removeClass('current')
    //                 .eq(number)
    //                 .addClass('current');
    //     });
    //     owl2.on("click", ".owl-item", function (e) {
    //         var number = $(this).index();
    //         console.log('owl2 click index = ' + number);
    //         owl1.trigger("to.owl.carousel", [number, 300, true]);
    //     });
    // }
    // }
});


$(window).on('load resize', function () {
    if ($('[data-height="one-tovar-info"]').length) {
        thumbMargin = 12;
        infoHeight = $('[data-height="one-tovar-info"]').outerHeight();
        infoThumbsCnt = $('.one-tovar__main__gallery__thumbs .one-tovar__main__gallery__thumbs__thumb').length;
        infoThumbsWidth = $('.one-tovar__main__gallery__thumbs .one-tovar__main__gallery__thumbs__thumb').width();
        thumbHeight = (infoHeight - (infoThumbsCnt - 1) * thumbMargin) / infoThumbsCnt;
        thumbHeight = Math.min(infoThumbsWidth, thumbHeight, 50);
        $('.one-tovar__main__gallery__thumbs .one-tovar__main__gallery__thumbs__thumb')
                .css('height', thumbHeight)
                .css('margin-bottom', thumbMargin);
        $('.one-tovar__main__gallery__thumbs .one-tovar__main__gallery__thumbs__thumb').each(function () {
        });
    }
    if (window.matchMedia('(min-width: 768px)').matches) {
        $('.tovar-anons__info__wrapper').each(function () {
            var bHeight = $(this).outerHeight();
            // $('.tovar-anons__block__info').css({'min-height':bHeight + 'px'});
            $(this).siblings('.tovar-anons__block__image').find('.tovar-anons__image').css({'height':bHeight + 'px'});
            $(this).css({'height':bHeight + 'px'});
        });
        if ($('#form1').length) {
            var formLeft = $('#form1').offset().left + $('#form1').outerWidth();
            $('.form__wrapper__bg').css({'left' : formLeft + 'px'});
            // console.log("formLeft: "+formLeft);
        }
    };

    var partnerHeight = 0;
    $('.partner__item').each(function () {
        partnerHeight = Math.max(partnerHeight, $(this).outerHeight());
    });
    $('.partner__image').css({'height':partnerHeight + 'px'});
});


MyDialog = {
    SelectDevelop: function (id)
    {
        Loading.StartLoading();
        if (id > 0) {
            $('.complex-item6__title').removeClass('complex-item6__title--active');
            $('#develop'+id).addClass('complex-item6__title--active');
            $('.complex-item6__descr').addClass('dnone');
            $('#developMore'+id).removeClass('dnone');
        }
        Loading.EndLoading();
    },
    ShowMore: function (cat, count, offset, lang, url, type_item) {
        Loading.StartLoading();
		$.post(
			'/tools/showmore.php',
			{type: "html", cat: cat, count: count, offset: offset, lang: lang, page_url: url, type_item: type_item},
			function (data) {
                $('#ArticlesList').append(data);
			},
			"html"
		);
		Loading.EndLoading();
	},
    ShowAuthor: function (author, lang) {
        Loading.StartLoading();
		$.post(
			'/tools/showauthor.php',
			{type: "html", author: author, lang: lang},
			function (data) {
                $('#showAuthor').html(data);
			},
			"html"
		);
		Loading.EndLoading();
	},
}

Login = {
    ClickLogin: function (jsOnLoad)
    {
        Loading.StartLoading();
        $('#ajaxModal #myModalLabel').html($('#login-form').data('title'));
        $('#ajaxModal .modal-body').html($('#login-form').html());
        $('#ajaxModal').modal();
        /*
         $.post('/tools/login/', {action: "login", jsOnLoad: jsOnLoad},
         function (data) {
         $('#ajaxModalLogin #myModalLabel').html(data.title);
         $('#ajaxModalLogin .modal-body').html(data.html);
         $('#ajaxModalLogin').modal();
         },
         "json");
         */
        Loading.EndLoading();
    },
    ActionLogin: function ()
    {
        Loading.StartLoading();
        if ($('#loginAction').val() == "login")
        {
            var param = $('#formLogin').serialize();
            $.post('/tools/login/', param,
                    function (data) {
                        $('#ajaxModal #myModalLabel').html(data.title);
                        $('#ajaxModal .modal-body').html(data.html);
                        $('#ajaxModal').modal();
                    }, "json");
        }
        Loading.EndLoading();
    },
    AffterLogin: function (v, m, f)
    {
        Loading.StartLoading();
        if (v)
        {
            document.location = m.children('a').attr('href');
        }
        Loading.EndLoading();
    },
}


Profile = {
    PhoneAdd: function (val) {
        var div = $('<div class="form-group">' + $('#profile-dop-phone').html() + '</div>');
        if (val) {
            div.find('input').attr('value', val);
        }
        $('#profile-dop-phone+div').append(div);
        // $('input[name="phone[]"]').mask("+38(099) 999-99-99");
        $('input[name="phone[]"]').inputmask("+38 099 999 99 99");
    },
    AdresAdd: function (val) {
        var div = $('<div class="form-group">' + $('#profile-dop-adres').html() + '</div>');
        if (val) {
            div.find('input').attr('value', val);
        }
        $('#profile-dop-adres+div').append(div);
    },
    RemoveInput: function (el) {
        el.closest('.form-group').remove();
    }
};


AjaxForm = {
    Subscribe: function (email) {
        $('#bottom_subscribe').val('');
        $.post('/tools/subscribe/', {
            action: 'add2',
            email: email
        }, function (data) {
            $('#ajaxModal #myModalLabel').html(data.title);
            $('#ajaxModal .modal-body').html(data.html);
            $('#ajaxModal').modal();
        }, "json");
    },
    ContentPager: function (offset, limit, type, url) {
        $.post('/tools/ajaxform/',
                {form: 'contentPager', offset: offset, limit: limit, type: type, new_request_url: url},
                function (data) {
                    $('#contentPager').before(data.tovars);
                    $('#contentPager').html(data.pager);
                }, "json");
    },
    CatalogPager: function (offset, limit, url) {
        $.post('/tools/ajaxform/',
                {form: 'catalogPager', offset: offset, limit: limit, new_request_url: url},
                function (data) {
                    $('#catalogPager').before(data.tovars);
                    $('#catalogPager').html(data.pager);
                }, "json");
    },
    OnetovarInfo: function (id, container, href) {
        Loading.StartLoading();
        if (href) {
            history.pushState(null, null, href);
        }
        $.post('/tools/ajaxform/', {
            form: 'onetovarinfo',
            id: id
        }, function (data) {
            if (data.result == 1) {
                $(container).html(data.html);
            }
            Loading.EndLoading();
        }, "json").fail(function () {
            //document.location.href = href;
            Loading.EndLoading();
        });
    },
    Register: function (start)
    {
        post = start ? '' : $('#registerAJAX').serialize();
        $.post('/tools/ajaxform/',
                {form: 'register', post: post},
                function (data) {
                    $('#ajaxModal #myModalLabel').html(data.title);
                    $('#ajaxModal .modal-body').html(data.html);
                    $('#ajaxModal').modal();
                }, "json");
    },
    Amneziy: function (start)
    {
        post = start ? '' : $('#formAJAX').serialize();
        $.post('/tools/ajaxform/',
                {form: 'amneziy', post: post},
                function (data) {
                    $('#ajaxModal #myModalLabel').html(data.title);
                    $('#ajaxModal .modal-body').html(data.html);
                    $('#ajaxModal').modal();
                }, "json");
    },
    CallMe: function (start)
    {
        post = start ? '' : $('#formAJAX').serialize();
        $.post('/tools/ajaxform/',
                {form: 'callme', post: post},
                function (data) {
                    $('#ajaxModal #myModalLabel').html(data.title);
                    $('#ajaxModal .modal-body').html(data.html);
                    $('#ajaxModal').modal();
                }, "json");
    },
    CostRequest: function (start='')
    {
        // post = start ? '' : $('#formAJAX').serialize();
        post = $('#formAJAX').serialize();
        $.post(
            '/tools/ajaxform/',
            {form: 'costrequest', post: post, product_name: start},
            function (data) {
                if (data.hide_title == 0) {
                    $('#ajaxModal #myModalLabel').html(data.title);
                } else {
                    $('#ajaxModal #myModalLabel').html('');
                }
                $('#ajaxModal .modal-body').html(data.html);
                $('#ajaxModal #product_name').prop('value', data.product_name);
                $('#ajaxModal').modal();
            },
            "json"
        );
    },
    Feedback4: function (start='')
    {
        // post = start ? '' : $('#formAJAX').serialize();
        // formAJAX
        if (start) {
            var
                commentForm = document.forms.formAJAX,
                formData = new FormData(commentForm)
            ;

            $.ajax({
                url: '/tools/ajaxform/',
                type: 'POST',
                data: formData,
                success: function (data) {
                    var data = jQuery.parseJSON(data);
                    // console.log(data);
                    if (data.hide_title == 0) {
                        $('#ajaxModal #myModalLabel').html(data.title);
                    } else {
                        $('#ajaxModal #myModalLabel').html('');
                    }
                    $('#ajaxModal .modal-body').html(data.html);
                    $('#ajaxModal').modal();
                },
                cache: false,
                contentType: false,
                processData: false
            });
        } else {
            post = $('#formAJAX').serialize();
            $.post(
                '/tools/ajaxform/',
                {form: 'feedback4', post: post},
                function (data) {
                    if (data.hide_title == 0) {
                        $('#ajaxModal #myModalLabel').html(data.title);
                    } else {
                        $('#ajaxModal #myModalLabel').html('');
                    }
                    $('#ajaxModal .modal-body').html(data.html);
                    // $('#ajaxModal #product_name').prop('value', data.product_name);
                    $('#ajaxModal').modal();
                },
                "json"
            );
        }
    },
    // CostRequest: function (start='')
    // {
    //     // post = start ? '' : $('#formAJAX').serialize();
    //     post = $('#formAJAX').serialize();
    //     $.post('/tools/ajaxform/',
    //             {form: 'costrequest', post: post, product_name: start},
    //             function (data) {
    //                 $('#ajaxModal #myModalLabel').html(data.title);
    //                 $('#ajaxModal .modal-body').html(data.html);
    //                 $('#ajaxModal #product_name').prop('value', data.product_name);
    //                 $('#ajaxModal').modal();
    //             }, "json");
    // },
}


Loading = {
    StartLoading: function ()
    {
        if (!$('body>#cms-loading').size()) {
            $('body').append('<div id="cms-loading"></div>');
        }
        $('body>#cms-loading').show().animate({"opacity": 1}, 300);
        document.body.style.cursor = "wait";
    },
    EndLoading: function ()
    {
        $('body>#cms-loading').animate({"opacity": 0}, 200).hide();
        document.body.style.cursor = "default";
    }
}


var Favorit = {
    toFavorit: function (tovarid, reload)
    {
        $.post('/tools/ajaxform/', {form: 'tofavorit', id: tovarid}, function (data) {
            $('.favorit-id-' + tovarid).removeClass('inFavorit');
            $('.favorit-id-' + tovarid + ' .fa').addClass('fa-spin');
            if (data.result) {
                $('.favorit-id-' + tovarid).addClass('inFavorit');
            }
            $('.favorit-id-' + tovarid + ' .fa').removeClass('fa-spin');
            $('#FavoritCount').html(data.cnt);
            if (reload) {
                location.reload();
            }
        }, "json");
    }
}


var Cart = {
    show: function (scrollTop)
    {
        Loading.StartLoading();
        $.post('/tools/cart/',
                {
                    event: 'showBasketAjax'
                },
                function (data) {
                    $('#ajaxModal #myModalLabel').html(data.title);
                    $('#ajaxModal .modal-body').html(data.html);
                    $('#ajaxModal').modal();
                    // tooltip
                    if (!$('body').hasClass('touch-device')) {
                        $('[data-toggle="tooltip"]').tooltip();
                    }
                    $('.ajax-cart__scroll').scrollTop(scrollTop);
                }, "json");
        Loading.EndLoading();
    },
    recalc: function ()
    {
        if (!$('.ajax-cart .ajax-cart__table__tr .ajax-cart__table__tr__cnt span').length) {
            if ($('.pageCartPage .order-cart>.ajax-cart').length) {
                location.reload();
            } else {
                Cart.show();
            }
        } else {
            $('.ajax-cart .ajax-cart__table__tr .ajax-cart__table__tr__cnt span').each(function () {
                var cnt = parseInt($(this).html());
                var line = $(this).closest('.ajax-cart__table__tr');
                elm = line.find('.ajax-cart__table__tr__price .tovars-top__price-old');
                if (elm.data('default') > 0)
                    elm.find('span').html(cnt * elm.data('default'));
                elm = line.find('.ajax-cart__table__tr__price .tovars-top__price-full');
                if (elm.data('default') > 0)
                    elm.find('span').html(cnt * elm.data('default'));
            });
            Loading.StartLoading();
            $.post('/tools/cart/', {
                event: 'showBasketAjax',
                mode: 'footer',
                delivery: $('#order-delivery option:selected').attr('price')
            },
                    function (data) {
                        $('.ajax-cart__footer').html(data.html);
                    }, "json");
            Loading.EndLoading();
        }
    },
    deleteItem: function (id_tovar, elm)
    {
        $(elm).closest('.ajax-cart__table__tr').remove();
        $.post('/tools/cart/',
                {
                    event: 'deleteItemBasketAjax',
                    id_tovar: id_tovar
                },
                function (data) {
                    if ($('.ajax-cart').length) {
                        Cart.recalc();
                    } else {
                        Cart.show(ajaxCartScroll);
                    }
                    //Cart.show();
                }, "json");
    },
    AddToCart: function (tovarid, kol)
    {
        Loading.StartLoading();
        if ($('.ajax-cart__scroll').size()) {
            ajaxCartScroll = $('.ajax-cart__scroll').scrollTop();
        } else {
            ajaxCartScroll = 0;
        }

        if (!tovarid)
        {
            Loading.EndLoading();
            $('#ajaxModal #myModalLabel').html('Системная ошибка');
            $('#ajaxModal .modal-body').html('Перезагрузите страницу и повторите попытку.');
            $('#ajaxModal').modal();
        } else {
            $.post('/tools/cart/', {
                event: "add", tovarid: tovarid, kol: kol
            }, function (data) {
                if (data.return) {
                    if ($('.modal.in .ajax-cart').length || $('.pageCartPage .ajax-cart').length) {
                        $('.cart_cnt_' + data.return).html(data.res_cnt);
                        Cart.recalc();
                    } else {
                        Cart.show(ajaxCartScroll);
                    }
                }
            }, "json");
        }
        Loading.EndLoading();
    },
    Available: function (tovarid, post) {
        Loading.StartLoading();

        if (!tovarid) {
            Loading.EndLoading();
            return;
        } else {
            $.post('/tools/cart/',
                    {
                        event: "available", tovarid: tovarid, form: post
                    },
                    function (data) {
                        $('#ajaxModal #myModalLabel').html(data.title);
                        $('#ajaxModal .modal-body').html(data.html);
                        $('#ajaxModal').modal();
                    }, "json");
        }
        Loading.EndLoading();
    }
}


CompareTovar = {
    compare: function (catid, tovarid)
    {
        Loading.StartLoading();
        if (!tovarid || !catid) {
            Loading.EndLoading();
            return false;
        }

        $.post('/tools/compare/',
                {type: "json", cmpcatid: catid, cmptovarid: tovarid},
                function (data) {
                    $('.comparetovar' + tovarid).removeClass('compared');
                    $('#CompareCount').html(data.cnt);
                    if (data.isadd) {
                        $('.comparetovar' + tovarid).addClass('compared');
                    }
                }, "json");

        Loading.EndLoading();
    },
}
