<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = urldecode($_POST['firstname']);
    $lname = urldecode($_POST['lastname']);
    $email = urldecode($_POST['email']);
    $phone = urldecode($_POST['phone']);
    $phonecc = urldecode($_POST["selectedCountryCode"]);
    $age=urldecode($_POST["age"]);
    $date=urldecode($_POST["country"]);
    $investment=urldecode($_POST["lang"]);

    // Об'єднайте phonecc та phone в одну змінну sub_id_13 country lang
    $sub_id_13 = $phonecc . $phone;

// Виконання постбеку лише у разі, якщо номер телефону валідний
    $postbackURL = "http://185.190.250.74/2244c9d/postback";
    $postbackURL .= "?subid=" . urlencode($_POST['sub1']) . "&status=REPLACE&payout=REPLACE";
    $postbackURL .= "&sub_id_12=" . urlencode($name) . "&sub_id_13=" . urlencode($sub_id_13) . "&sub_id_7=" . urlencode($lname) . "&sub_id_14=" . urlencode($email) . "&sub_id_15=" . urlencode($age) . "&sub_id_16=" . urlencode($date) . "&sub_id_17=" . urlencode($investment);

// Отримання відповіді від сервера при виконанні постбеку
    $postbackResponse = file_get_contents($postbackURL);

    var_dump($postbackURL);
}

//    // Ваш початковий код для виконання запиту на перевірку номера телефону
//    $ch = curl_init();
//    curl_setopt($ch, CURLOPT_URL, 'https://phonevalidation.abstractapi.com/v1/?api_key=66fa19be2f974c72a1f46bc311469c1e&phone=' . urlencode($sub_id_13));
//    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
//    $validationData = curl_exec($ch);
//    curl_close($ch);
//
//    var_dump($validationData);
//
//    // Перевірка наявності відповіді та її змісту
//    if ($validationData) {
//        $responseData = json_decode($validationData, true);
//        // Перевірка, чи повернулася відповідь True
//        if ($responseData && isset($responseData['valid']) && $responseData['valid'] === true) {
//            // Виконання постбеку лише у разі, якщо номер телефону валідний
//            $postbackURL = "http://185.190.250.74/2244c9d/postback";
//            $postbackURL .= "?subid=" . urlencode($_POST['sub1']) . "&status=REPLACE&payout=REPLACE";
//            $postbackURL .= "&sub_id_12=" . urlencode($name) . "&sub_id_13=" . urlencode($sub_id_13) . "&sub_id_7=" . urlencode($lname) . "&sub_id_14=" . urlencode($email) . "&sub_id_15=" . urlencode($company) . "&sub_id_16=" . urlencode($date) . "&sub_id_17=" . urlencode($investment);
//
//            // Отримання відповіді від сервера при виконанні постбеку
//            $postbackResponse = file_get_contents($postbackURL);
//
//            // Виведення відповіді в форматі JSON
//            header('Content-Type: application/json');
//            echo json_encode(array(
//                'success' => true,
//                'message' => 'A postback for a valid phone number has been performed',
//                'postback_response' => $postbackResponse,
//                'validation_data' => $responseData
//            ));
//        } else {
//            // Виведення відповіді про недійсний номер телефону
//            header('Content-Type: application/json');
//            echo json_encode(array(
//                'success' => false,
//                'message' => 'An invalid phone number was received. Enter the number as example +7 XXX XXX-XX-XX',
//                'validation_data' => $responseData
//            ));
//        }
//    } else {
//        // Виведення відповіді про відсутність відповіді від API перевірки номера телефону
//        header('Content-Type: application/json');
//        echo json_encode(array(
//            'success' => false,
//            'message' => 'No response was received from the telephone validation API'
//        ));
//    }
//}

?>